import {
  users,
  lessonCategories,
  lessons,
  userProgress,
  achievements,
  userAchievements,
  type User,
  type InsertUser,
  type LessonCategory,
  type Lesson,
  type UserProgress,
  type Achievement,
  type UserAchievement,
  type InsertUserProgress,
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  updateUserSubscription(userId: number, tier: string, status: string, premiumUntil?: Date): Promise<User>;
  
  getLessonCategories(): Promise<LessonCategory[]>;
  getLessonsByCategory(categoryId: number): Promise<Lesson[]>;
  getLesson(id: number): Promise<Lesson | undefined>;
  getPremiumLessons(): Promise<Lesson[]>;
  
  getUserProgress(userId: number): Promise<UserProgress[]>;
  updateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  
  getAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  addUserAchievement(userId: number, achievementId: number): Promise<UserAchievement>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private lessonCategories: Map<number, LessonCategory>;
  private lessons: Map<number, Lesson>;
  private userProgress: Map<string, UserProgress>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<string, UserAchievement>;
  private currentUserId: number;
  private currentProgressId: number;
  private currentAchievementId: number;

  constructor() {
    this.users = new Map();
    this.lessonCategories = new Map();
    this.lessons = new Map();
    this.userProgress = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.currentUserId = 1;
    this.currentProgressId = 1;
    this.currentAchievementId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize lesson categories focused on advanced financial concepts
    const categories: LessonCategory[] = [
      { id: 1, name: "Stock Market Safari", description: "Join Captain Cash on an adventure to understand how companies sell tiny pieces of themselves and how you can own them too!", color: "green", icon: "fas fa-chart-line", order: 1 },
      { id: 2, name: "Day Trading Detectives", description: "Explore with Flash the Fox how some people buy and sell stocks super fast - and why it's risky business!", color: "red", icon: "fas fa-bolt", order: 2 },
      { id: 3, name: "Career Cash Academy", description: "Discover with Professor Success how to find amazing jobs, write resumes, and ace interviews to earn money!", color: "blue", icon: "fas fa-briefcase", order: 3 },
      { id: 4, name: "Free Fun Financial Club", description: "Learn with Thrifty the Turtle about amazing free activities and money-saving hacks that keep cash in your pocket!", color: "green", icon: "fas fa-leaf", order: 4 },
      { id: 5, name: "Home Buying Heroes", description: "Learn with Ruby the Realtor about mortgages, down payments, and how adults buy their dream homes!", color: "orange", icon: "fas fa-home", order: 5 },
      { id: 6, name: "Retirement Rangers", description: "Discover with Wise Owl Winston how 401(k) plans help adults save money for when they're old and want to stop working!", color: "purple", icon: "fas fa-piggy-bank", order: 6 },
      { id: 7, name: "Investment Investigators", description: "Solve money mysteries with Detective Dollar about bonds, mutual funds, and how to make your money work for you!", color: "indigo", icon: "fas fa-search-dollar", order: 7 },
      { id: 8, name: "Credit Card Captains", description: "Navigate the tricky waters of credit cards, credit scores, and borrowing money responsibly with Captain Credit!", color: "pink", icon: "fas fa-credit-card", order: 8 },
      { id: 9, name: "Tax Time Teachers", description: "Learn with Professor Penny why adults give some of their money to the government and how taxes help build schools and roads!", color: "yellow", icon: "fas fa-calculator", order: 9 },
      { id: 10, name: "Wealth Wisdom Warriors", description: "Master advanced financial strategies with Sage the Eagle - from emergency funds to passive income!", color: "gold", icon: "fas fa-crown", order: 10 },
      { id: 11, name: "Insurance Investigators", description: "Protect your future with Shield the Guardian - learn about health, life, and auto insurance!", color: "cyan", icon: "fas fa-shield-alt", order: 11 },
      { id: 12, name: "Debt Destroyers", description: "Conquer debt with Crusher the Rhino - strategies for paying off loans and staying debt-free!", color: "purple", icon: "fas fa-hammer", order: 12 },
      { id: 13, name: "Entrepreneur Eagles", description: "Start your own business with Boss the Lion - from side hustles to full companies!", color: "orange", icon: "fas fa-rocket", order: 13 },
    ];
    categories.forEach(cat => this.lessonCategories.set(cat.id, cat));

    // Initialize lessons with advanced financial concepts for kids
    const sampleLessons: Lesson[] = [
      { 
        id: 1, 
        categoryId: 1, 
        title: "What Are Stocks?", 
        description: "Captain Cash explains how you can own tiny pieces of your favorite companies!", 
        content: { 
          type: "interactive", 
          character: "Captain Cash",
          sections: [
            {
              type: "intro",
              title: "Welcome to the Stock Market Safari!",
              content: "Ahoy there, young investor! I'm Captain Cash, and I'm here to teach you about something AMAZING called stocks! Did you know you can actually own a tiny piece of Disney, Apple, or McDonald's?"
            },
            {
              type: "story",
              title: "The Pizza Shop Story",
              content: "Imagine your friend Sarah opens a pizza shop and needs $1,000 to start. She could sell 100 'shares' for $10 each. If you buy 1 share, you own 1% of her pizza business! If the pizza shop makes money, your share becomes worth more!"
            },
            {
              type: "quiz",
              title: "Stock Quiz!",
              question: "If you own 5 shares of a company that has 100 total shares, what percentage do you own?",
              options: ["5%", "10%", "50%"],
              correct: 0
            },
            {
              type: "activity",
              title: "Stock Market Game",
              content: "Let's pretend to buy stocks! Pick 3 companies you know and love. Research their stock prices. Which one would you invest in and why?"
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 20 
      },
      { 
        id: 2, 
        categoryId: 2, 
        title: "Buying Your Dream Home", 
        description: "Ruby the Realtor teaches about mortgages and how adults buy houses!", 
        content: { 
          type: "interactive", 
          character: "Ruby the Realtor",
          sections: [
            {
              type: "intro",
              title: "Meet Ruby the Realtor!",
              content: "Hello future homeowner! I'm Ruby, and I help families find their perfect homes. But houses cost A LOT of money - sometimes $300,000 or more! So how do people buy them?"
            },
            {
              type: "story",
              title: "The Mortgage Mystery",
              content: "Most people don't have $300,000 sitting around! So they use something called a MORTGAGE. It's like the bank lends them the money to buy the house, and they pay it back little by little over 30 years!"
            },
            {
              type: "quiz",
              title: "Home Buying Quiz!",
              question: "If a house costs $200,000 and you pay $40,000 as a down payment, how much do you need to borrow?",
              options: ["$160,000", "$180,000", "$240,000"],
              correct: 0
            }
          ]
        }, 
        order: 2, 
        estimatedMinutes: 12 
      },
      { 
        id: 3, 
        categoryId: 3, 
        title: "401(k) Retirement Plans", 
        description: "Wise Owl Winston explains how adults save for retirement!", 
        content: { 
          type: "interactive", 
          character: "Wise Owl Winston",
          sections: [
            {
              type: "intro",
              title: "Planning for the Future!",
              content: "Hoot hoot! I'm Winston, and I'm very wise about planning ahead. Did you know that adults start saving for retirement when they're young - even in their 20s? Let me tell you about 401(k) plans!"
            },
            {
              type: "story",
              title: "The Magic of 401(k)",
              content: "A 401(k) is like a special piggy bank at work! Every month, some money from your paycheck goes into this account. The AMAZING part? Your company often adds extra money too - it's like getting free money for saving!"
            },
            {
              type: "quiz",
              title: "Retirement Quiz!",
              question: "If you save $100 per month and your company matches 50%, how much total goes into your 401(k) each month?",
              options: ["$100", "$150", "$200"],
              correct: 1
            }
          ]
        }, 
        order: 3, 
        estimatedMinutes: 16 
      },
      { 
        id: 4, 
        categoryId: 4, 
        title: "Bonds and Mutual Funds", 
        description: "Detective Dollar solves the mystery of different investment types!", 
        content: { 
          type: "interactive", 
          character: "Detective Dollar",
          sections: [
            {
              type: "intro",
              title: "The Case of the Missing Money!",
              content: "Elementary, my dear investor! Detective Dollar here. Today we're solving the mystery of bonds and mutual funds - two ways adults make their money grow besides stocks!"
            },
            {
              type: "story",
              title: "The Bond Mystery",
              content: "A bond is like lending money to a company or government. They promise to pay you back PLUS extra money (called interest) after a few years. It's safer than stocks but grows slower."
            },
            {
              type: "activity",
              title: "Investment Detective Game",
              content: "Case: You have $1,000 to invest. Stock: Risky but could double. Bond: Safe, grows 3% per year. Mutual Fund: Mix of many stocks. What's your strategy?"
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 22 
      },
      { 
        id: 5, 
        categoryId: 5, 
        title: "Credit Cards and Credit Scores", 
        description: "Captain Credit teaches the secrets of borrowing money responsibly!", 
        content: { 
          type: "interactive", 
          character: "Captain Credit",
          sections: [
            {
              type: "intro",
              title: "Ahoy, Future Adults!",
              content: "Greetings! I'm Captain Credit, and I navigate the sometimes tricky waters of credit cards and credit scores. These are VERY important for adults - let me show you why!"
            },
            {
              type: "story",
              title: "The Credit Score Adventure",
              content: "Your credit score is like a report card for how good you are with borrowed money. If you borrow money and pay it back on time, you get a good score (like an A+). This helps you buy houses and cars later!"
            },
            {
              type: "quiz",
              title: "Credit Quiz!",
              question: "What's the best way to build a good credit score?",
              options: ["Borrow lots of money", "Pay bills on time", "Never use credit"],
              correct: 1
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 18 
      },
      { 
        id: 6, 
        categoryId: 2, 
        title: "Day Trading: The Speed Game", 
        description: "Flash the Fox explains why buying and selling stocks super fast is risky!", 
        content: { 
          type: "interactive", 
          character: "Flash the Fox",
          sections: [
            {
              type: "intro",
              title: "Super Fast Trading!",
              content: "Hi there! I'm Flash the Fox, and I'm REALLY fast! Some people try to buy and sell stocks as fast as me - it's called day trading. But here's the thing... it's very risky!"
            },
            {
              type: "story",
              title: "The Speedy Trap",
              content: "Day traders buy stocks in the morning and sell them the same day, hoping to make quick money. But most day traders actually LOSE money! It's like gambling - you might win sometimes, but you'll probably lose more than you gain."
            },
            {
              type: "activity",
              title: "Trading Speed Challenge",
              content: "SIMULATION: You have $1,000. Stock X starts at $100. Every 10 seconds it changes: $102→$98→$105→$95→$110. When do you buy/sell? Calculate your profit/loss after 5 trades. Most lose money!"
            },
            {
              type: "quiz",
              title: "Day Trading Quiz!",
              question: "What percentage of day traders lose money over time?",
              options: ["20%", "50%", "80%"],
              correct: 2
            },
            {
              type: "quiz",
              title: "Risk Assessment Quiz!",
              question: "Why is day trading so risky for beginners?",
              options: ["Need lots of experience and knowledge", "Stock prices are unpredictable", "Both answers are correct"],
              correct: 2
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 15 
      },
      { 
        id: 7, 
        categoryId: 3, 
        title: "Finding Your Dream Job", 
        description: "Professor Success teaches how to search for jobs and ace interviews!", 
        content: { 
          type: "interactive", 
          character: "Professor Success",
          sections: [
            {
              type: "intro",
              title: "Career Success Secrets!",
              content: "Greetings, future professional! I'm Professor Success, and I'll teach you how adults find great jobs. It's not just about luck - it's about strategy!"
            },
            {
              type: "story",
              title: "The Job Hunt Journey",
              content: "Finding a job is like solving a puzzle! You need skills (education/experience), a great resume, interview practice, and networking. The best jobs often come from people you know - 70% of jobs are never posted online!"
            },
            {
              type: "activity",
              title: "Career Planning Game",
              content: "Pick your dream job: Doctor, Engineer, Teacher, Artist, CEO. What education do you need? What skills? Create a 10-year plan: High school → College/Trade school → Internships → Entry job → Dream job!"
            },
            {
              type: "quiz",
              title: "Job Search Quiz!",
              question: "What's the best way to find jobs?",
              options: ["Only online applications", "Networking with people", "Both online and networking"],
              correct: 2
            },
            {
              type: "quiz",
              title: "Resume Building Quiz!",
              question: "What should you highlight most on your resume?",
              options: ["Your achievements and results", "How much money you want", "Your hobbies"],
              correct: 0
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 20 
      },
      { 
        id: 8, 
        categoryId: 4, 
        title: "Free Fun and Money Saving", 
        description: "Thrifty the Turtle shares amazing free activities and money-saving tricks!", 
        content: { 
          type: "interactive", 
          character: "Thrifty the Turtle",
          sections: [
            {
              type: "intro",
              title: "Slow and Steady Saves Money!",
              content: "Hello friend! I'm Thrifty the Turtle. I may be slow, but I'm AMAZING at finding free fun and saving money. Let me share my secrets!"
            },
            {
              type: "story",
              title: "The Money-Saving Mindset",
              content: "Being thrifty doesn't mean being cheap - it means being SMART! You can have fun without spending lots of money. Libraries, parks, free museums, hiking, beach days, community events - so much fun costs nothing!"
            },
            {
              type: "activity",
              title: "Saving Plan Calculator",
              content: "Let's create your personal saving plan! Pick something you want to buy, figure out how much it costs, and plan how much you can save each week. The calculator below will show you exactly when you'll reach your goal!"
            },
            {
              type: "quiz",
              title: "Money-Saving Quiz!",
              question: "What's the best way to save money on entertainment?",
              options: ["Stay home all the time", "Find free activities you enjoy", "Only do expensive things occasionally"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Smart Shopping Quiz!",
              question: "Before buying something, you should ask:",
              options: ["Do I really need this?", "Can I find it cheaper elsewhere?", "Both questions"],
              correct: 2
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 14 
      },
      { 
        id: 14, 
        categoryId: 6, 
        title: "401(k) and Retirement Planning", 
        description: "Wise Owl Winston teaches about saving for the future!", 
        content: { 
          type: "interactive", 
          character: "Wise Owl Winston",
          sections: [
            {
              type: "intro",
              title: "Planning for the Future!",
              content: "Hoot hoot! I'm Winston, and I'm very wise about planning ahead. Did you know that adults start saving for retirement when they're young - even in their 20s? Let me tell you about 401(k) plans!"
            },
            {
              type: "story",
              title: "The Magic of 401(k)",
              content: "A 401(k) is like a special piggy bank at work! Every month, some money from your paycheck goes into this account. The AMAZING part? Your company often adds extra money too - it's like getting free money for saving!"
            },
            {
              type: "activity",
              title: "Retirement Planning Calculator",
              content: "COMPOUND INTEREST MAGIC: Start with $0. Save $200/month starting at age 22. With 7% growth: Age 30=$25K, Age 40=$131K, Age 50=$367K, Age 65=$1.37 MILLION! Start early = retire rich!"
            },
            {
              type: "quiz",
              title: "Retirement Quiz!",
              question: "If you save $100 per month and your company matches 50%, how much total goes into your 401(k) each month?",
              options: ["$100", "$150", "$200"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Compound Interest Quiz!",
              question: "Why is starting to save for retirement early so powerful?",
              options: ["You'll have more time to save", "Compound interest has more time to work", "Both reasons"],
              correct: 2
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 20 
      },
      { 
        id: 15, 
        categoryId: 7, 
        title: "Advanced Investment Strategies", 
        description: "Detective Dollar solves complex investment mysteries!", 
        content: { 
          type: "interactive", 
          character: "Detective Dollar",
          sections: [
            {
              type: "intro",
              title: "The Case of Advanced Investing!",
              content: "Elementary, my dear investor! Detective Dollar here. Today we're solving advanced investment mysteries - ETFs, index funds, REITs, and portfolio diversification!"
            },
            {
              type: "story",
              title: "The Diversification Mystery",
              content: "Never put all your eggs in one basket! Smart investors spread their money across different types of investments: stocks, bonds, real estate, international markets, and different industries."
            },
            {
              type: "activity",
              title: "Portfolio Builder Game",
              content: "Build your dream portfolio: 60% stocks, 30% bonds, 10% alternative investments. Choose from tech stocks, utility companies, government bonds, corporate bonds, REITs, and international funds!"
            },
            {
              type: "quiz",
              title: "Diversification Quiz!",
              question: "What's the main benefit of diversifying your investments?",
              options: ["Higher guaranteed returns", "Reduced risk", "More complicated taxes"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Investment Types Quiz!",
              question: "What does an ETF (Exchange Traded Fund) allow you to do?",
              options: ["Buy one stock", "Buy many stocks at once", "Only buy bonds"],
              correct: 1
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 24 
      },
      { 
        id: 16, 
        categoryId: 8, 
        title: "Mastering Credit and Loans", 
        description: "Captain Credit navigates advanced credit strategies!", 
        content: { 
          type: "interactive", 
          character: "Captain Credit",
          sections: [
            {
              type: "intro",
              title: "Advanced Credit Navigation!",
              content: "Ahoy, advanced learners! Captain Credit here with advanced credit knowledge - credit utilization, mortgage rates, refinancing, and building excellent credit scores!"
            },
            {
              type: "story",
              title: "The Credit Score Journey",
              content: "Excellent credit (750+ score) unlocks the best rates on everything: mortgages, car loans, business loans. Poor credit costs thousands extra in interest. Build it with: on-time payments, low utilization, long credit history, diverse credit types!"
            },
            {
              type: "activity",
              title: "Credit Score Builder Game",
              content: "Start with 650 credit score. Make choices: Pay bills on time (+20), Max out credit cards (-50), Apply for 5 cards in one month (-30), Pay off debt (+40). Can you reach 800?"
            },
            {
              type: "quiz",
              title: "Advanced Credit Quiz!",
              question: "What's the ideal credit utilization rate to maintain an excellent credit score?",
              options: ["Below 10%", "30-40%", "50%+"],
              correct: 0
            },
            {
              type: "quiz",
              title: "Credit History Quiz!",
              question: "How long should you keep your oldest credit card account open?",
              options: ["Close it immediately", "Keep it open forever", "Close after 2 years"],
              correct: 1
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 20 
      },
      { 
        id: 9, 
        categoryId: 9, 
        title: "Understanding Taxes", 
        description: "Professor Penny explains why adults pay taxes and how they work!", 
        content: { 
          type: "interactive", 
          character: "Professor Penny",
          sections: [
            {
              type: "intro",
              title: "The Tax System Explained!",
              content: "Hello young scholars! I'm Professor Penny, and today we're learning about taxes - money that adults give to the government to pay for schools, roads, hospitals, and police!"
            },
            {
              type: "story",
              title: "Where Tax Money Goes",
              content: "When you buy something, you pay a little extra called sales tax. When adults work, they pay income tax. This money builds schools like yours, fixes roads you drive on, and pays firefighters who keep us safe!"
            },
            {
              type: "activity",
              title: "Tax Calculator Game",
              content: "SALARY: $50,000. Federal tax: 12% = $6,000. State tax: 5% = $2,500. Social Security: 6.2% = $3,100. Medicare: 1.45% = $725. Total taxes: $12,325. Take-home: $37,675. See how taxes fund society!"
            },
            {
              type: "quiz",
              title: "Tax Quiz!",
              question: "What do taxes help pay for?",
              options: ["Video games", "Schools and roads", "Personal cars"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Tax Types Quiz!",
              question: "What's the difference between sales tax and income tax?",
              options: ["Sales tax is on purchases, income tax is on earnings", "They're the same thing", "Sales tax is only for adults"],
              correct: 0
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 12 
      },
      { 
        id: 10, 
        categoryId: 10, 
        title: "Building Wealth Strategies", 
        description: "Sage the Eagle teaches advanced money-making techniques for adults!", 
        content: { 
          type: "interactive", 
          character: "Sage the Eagle",
          sections: [
            {
              type: "intro",
              title: "Soaring to Financial Heights!",
              content: "Greetings from above! I'm Sage the Eagle, and I see the big picture of wealth building. Let me share the secrets that make some adults very financially successful!"
            },
            {
              type: "story",
              title: "The Wealth-Building Formula",
              content: "Wealthy people follow this formula: Earn money → Save 20% or more → Invest in stocks, real estate, or businesses → Reinvest the profits → Repeat for many years. Time and compound growth do the magic!"
            },
            {
              type: "activity",
              title: "Wealth Building Simulator",
              content: "START: $0, Age 25. SCENARIO: Save $500/month, invest at 8% return. Age 35: $91K, Age 45: $274K, Age 55: $679K, Age 65: $1.5M. Try different amounts and see wealth grow!"
            },
            {
              type: "quiz",
              title: "Wealth Building Quiz!",
              question: "What's the most important factor in building wealth?",
              options: ["Making lots of money quickly", "Starting early and being consistent", "Taking big risks"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Passive Income Quiz!",
              question: "What's passive income?",
              options: ["Money you earn while sleeping", "Money from your regular job", "Money you borrow"],
              correct: 0
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 25 
      },
      { 
        id: 11, 
        categoryId: 11, 
        title: "Insurance Protection Plans", 
        description: "Shield the Guardian protects your future with insurance knowledge!", 
        content: { 
          type: "interactive", 
          character: "Shield the Guardian",
          sections: [
            {
              type: "intro",
              title: "Protecting What Matters!",
              content: "I am Shield the Guardian, protector of financial security! Insurance might seem boring, but it's like a superhero shield that protects adults from financial disasters!"
            },
            {
              type: "story",
              title: "Types of Insurance",
              content: "HEALTH INSURANCE: Pays for doctor visits and medicine. CAR INSURANCE: Fixes your car if you crash. LIFE INSURANCE: Takes care of your family if something happens to you. HOME INSURANCE: Rebuilds your house if it burns down."
            },
            {
              type: "activity",
              title: "Insurance Protection Game",
              content: "SCENARIOS: Hospital bill $50K (need health insurance), Car accident $20K damage (need auto insurance), House fire $200K (need home insurance). Calculate how much you'd pay without insurance!"
            },
            {
              type: "quiz",
              title: "Insurance Quiz!",
              question: "What does car insurance do?",
              options: ["Makes cars faster", "Pays for gas", "Pays for accident repairs"],
              correct: 2
            },
            {
              type: "quiz",
              title: "Insurance Value Quiz!",
              question: "Why is insurance important?",
              options: ["It prevents accidents", "It protects you from financial disasters", "It makes you money"],
              correct: 1
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 18 
      },
      { 
        id: 12, 
        categoryId: 12, 
        title: "Crushing Debt Forever", 
        description: "Crusher the Rhino destroys debt with powerful strategies!", 
        content: { 
          type: "interactive", 
          character: "Crusher the Rhino",
          sections: [
            {
              type: "intro",
              title: "Debt Destruction Time!",
              content: "CHARGE! I'm Crusher the Rhino, and I DESTROY debt! Debt is when you owe money to someone. Some debt is okay (like house loans), but credit card debt can be dangerous!"
            },
            {
              type: "story",
              title: "Debt Avalanche vs Snowball",
              content: "AVALANCHE METHOD: Pay minimum on all debts, put extra money toward the highest interest rate debt first. SNOWBALL METHOD: Pay minimum on all debts, put extra money toward the smallest debt first for motivation!"
            },
            {
              type: "activity",
              title: "Debt Destroyer Game",
              content: "DEBTS: Credit card $5K at 18%, Car loan $15K at 6%, Student loan $30K at 4%. Extra $500/month available. Use avalanche method: pay credit card first (highest rate), then car, then student loan!"
            },
            {
              type: "quiz",
              title: "Debt Strategy Quiz!",
              question: "Which debt should you pay off first using the avalanche method?",
              options: ["Smallest balance", "Highest interest rate", "Newest debt"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Good vs Bad Debt Quiz!",
              question: "Which is usually considered 'good debt'?",
              options: ["Credit card debt", "Home mortgage", "Payday loans"],
              correct: 1
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 20 
      },
      { 
        id: 13, 
        categoryId: 13, 
        title: "Starting Your Own Business", 
        description: "Boss the Lion teaches entrepreneurship and business creation!", 
        content: { 
          type: "interactive", 
          character: "Boss the Lion",
          sections: [
            {
              type: "intro",
              title: "Become the Boss!",
              content: "ROAR! I'm Boss the Lion, king of entrepreneurship! Starting a business means being your own boss and creating something that makes money. It's risky but can be very rewarding!"
            },
            {
              type: "story",
              title: "Business Ideas for Beginners",
              content: "EASY BUSINESSES TO START: Tutoring, pet sitting, lawn mowing, online selling, freelance writing, photography, cleaning services, food delivery, app development, consulting!"
            },
            {
              type: "activity",
              title: "Business Builder Challenge",
              content: "CREATE YOUR BUSINESS: Pick an idea (lemonade stand, dog walking, tutoring). Calculate: Startup costs $50, Price per service $10, Monthly expenses $20. How many customers needed to profit?"
            },
            {
              type: "quiz",
              title: "Entrepreneurship Quiz!",
              question: "What's the most important thing for a successful business?",
              options: ["Having lots of money", "Solving a problem people have", "Working alone"],
              correct: 1
            },
            {
              type: "quiz",
              title: "Business Planning Quiz!",
              question: "Before starting a business, you should:",
              options: ["Just start and figure it out", "Research your market and make a plan", "Copy someone else exactly"],
              correct: 1
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 22 
      }
    ];
    sampleLessons.forEach(lesson => this.lessons.set(lesson.id, lesson));

    // Initialize achievements focused on comprehensive financial mastery
    const sampleAchievements: Achievement[] = [
      { id: 1, name: "Stock Market Explorer", description: "Complete your first lesson about stocks with Captain Cash!", icon: "fas fa-chart-line", color: "green", requirement: "complete_first_stock_lesson" },
      { id: 2, name: "Day Trading Survivor", description: "Learn the risks of day trading with Flash the Fox!", icon: "fas fa-bolt", color: "red", requirement: "complete_day_trading_lesson" },
      { id: 3, name: "Career Hunter", description: "Master job searching strategies with Professor Success!", icon: "fas fa-briefcase", color: "blue", requirement: "complete_career_category" },
      { id: 4, name: "Thrifty Saver", description: "Discover free activities and money-saving hacks with Thrifty the Turtle!", icon: "fas fa-leaf", color: "green", requirement: "complete_saving_hacks_category" },
      { id: 5, name: "Future Homeowner", description: "Master mortgages and home buying with Ruby the Realtor!", icon: "fas fa-home", color: "orange", requirement: "complete_mortgage_category" },
      { id: 6, name: "Retirement Planner", description: "Learn 401(k) secrets with Wise Owl Winston!", icon: "fas fa-piggy-bank", color: "purple", requirement: "complete_retirement_category" },
      { id: 7, name: "Investment Detective", description: "Solve investment mysteries with Detective Dollar!", icon: "fas fa-search-dollar", color: "indigo", requirement: "complete_investment_category" },
      { id: 8, name: "Credit Card Captain", description: "Navigate credit responsibly with Captain Credit!", icon: "fas fa-credit-card", color: "pink", requirement: "complete_credit_category" },
      { id: 9, name: "Tax Time Scholar", description: "Understand taxes with Professor Penny!", icon: "fas fa-calculator", color: "yellow", requirement: "complete_tax_category" },
      { id: 10, name: "Wealth Wisdom Master", description: "Learn advanced strategies with Sage the Eagle!", icon: "fas fa-crown", color: "gold", requirement: "complete_wealth_category" },
      { id: 11, name: "Insurance Expert", description: "Protect your future with Shield the Guardian!", icon: "fas fa-shield-alt", color: "cyan", requirement: "complete_insurance_category" },
      { id: 12, name: "Debt Destroyer", description: "Crush all debts with Crusher the Rhino!", icon: "fas fa-hammer", color: "purple", requirement: "complete_debt_category" },
      { id: 13, name: "Future Entrepreneur", description: "Build business empires with Boss the Lion!", icon: "fas fa-rocket", color: "orange", requirement: "complete_entrepreneur_category" },
      { id: 14, name: "Financial Genius", description: "Complete ALL financial education categories!", icon: "fas fa-graduation-cap", color: "rainbow", requirement: "complete_all_categories" },
      { id: 15, name: "Future Millionaire", description: "Achieve perfect scores in ALL lessons - you're ready for financial success!", icon: "fas fa-trophy", color: "platinum", requirement: "perfect_scores_all_lessons" },
    ];
    sampleAchievements.forEach(achievement => this.achievements.set(achievement.id, achievement));
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      parentEmail: insertUser.parentEmail || null,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async getLessonCategories(): Promise<LessonCategory[]> {
    return Array.from(this.lessonCategories.values()).sort((a, b) => a.order - b.order);
  }

  async getLessonsByCategory(categoryId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter(lesson => lesson.categoryId === categoryId)
      .sort((a, b) => a.order - b.order);
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }

  async updateUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const key = `${progress.userId}-${progress.lessonId}`;
    const existing = this.userProgress.get(key);
    
    if (existing) {
      const updated: UserProgress = {
        ...existing,
        ...progress,
        completed: progress.completed ?? existing.completed,
        score: progress.score ?? existing.score,
        completedAt: progress.completed ? new Date() : existing.completedAt,
      };
      this.userProgress.set(key, updated);
      return updated;
    } else {
      const newProgress: UserProgress = {
        id: this.currentProgressId++,
        userId: progress.userId,
        lessonId: progress.lessonId,
        completed: progress.completed || false,
        score: progress.score || null,
        completedAt: progress.completed ? new Date() : null,
      };
      this.userProgress.set(key, newProgress);
      return newProgress;
    }
  }

  async getAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values()).filter(ua => ua.userId === userId);
  }

  async addUserAchievement(userId: number, achievementId: number): Promise<UserAchievement> {
    const key = `${userId}-${achievementId}`;
    const existing = this.userAchievements.get(key);
    
    if (existing) {
      return existing;
    }
    
    const userAchievement: UserAchievement = {
      id: this.currentAchievementId++,
      userId,
      achievementId,
      earnedAt: new Date(),
    };
    
    this.userAchievements.set(key, userAchievement);
    return userAchievement;
  }
}

export const storage = new MemStorage();
