import {
  users,
  lessonCategories,
  lessons,
  userProgress,
  achievements,
  userAchievements,
  type User,
  type InsertUser,
  type LessonCategory,
  type Lesson,
  type UserProgress,
  type Achievement,
  type UserAchievement,
  type InsertUserProgress,
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  updateUserSubscription(userId: number, tier: string, status: string, premiumUntil?: Date): Promise<User>;
  
  getLessonCategories(): Promise<LessonCategory[]>;
  getLessonsByCategory(categoryId: number): Promise<Lesson[]>;
  getLesson(id: number): Promise<Lesson | undefined>;
  getPremiumLessons(): Promise<Lesson[]>;
  
  getUserProgress(userId: number): Promise<UserProgress[]>;
  updateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  
  getAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  addUserAchievement(userId: number, achievementId: number): Promise<UserAchievement>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private lessonCategories: Map<number, LessonCategory>;
  private lessons: Map<number, Lesson>;
  private userProgress: Map<string, UserProgress>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<string, UserAchievement>;
  private currentUserId: number;
  private currentProgressId: number;
  private currentAchievementId: number;

  constructor() {
    this.users = new Map();
    this.lessonCategories = new Map();
    this.lessons = new Map();
    this.userProgress = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.currentUserId = 1;
    this.currentProgressId = 1;
    this.currentAchievementId = 1;
    
    this.initializeData();
  }

  async createUser(user: InsertUser): Promise<User> {
    const newUser: User = {
      id: this.currentUserId++,
      username: user.username,
      email: user.email,
      age: user.age,
      parentEmail: user.parentEmail || null,
      subscriptionTier: user.subscriptionTier || "free",
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      subscriptionStatus: "inactive",
      premiumUntil: null,
      createdAt: new Date(),
    };
    this.users.set(newUser.id, newUser);
    return newUser;
  }

  async updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      stripeCustomerId,
      stripeSubscriptionId: stripeSubscriptionId || user.stripeSubscriptionId,
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserSubscription(userId: number, tier: string, status: string, premiumUntil?: Date): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      subscriptionTier: tier,
      subscriptionStatus: status,
      premiumUntil: premiumUntil || null,
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getPremiumLessons(): Promise<Lesson[]> {
    return Array.from(this.lessons.values()).filter(lesson => lesson.isPremium);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getLessonCategories(): Promise<LessonCategory[]> {
    return Array.from(this.lessonCategories.values()).sort((a, b) => a.order - b.order);
  }

  async getLessonsByCategory(categoryId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter(lesson => lesson.categoryId === categoryId)
      .sort((a, b) => a.order - b.order);
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }

  async updateUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const key = `${progress.userId}-${progress.lessonId}`;
    const existingProgress = this.userProgress.get(key);
    
    const newProgress: UserProgress = {
      id: existingProgress?.id || this.currentProgressId++,
      userId: progress.userId,
      lessonId: progress.lessonId,
      completed: progress.completed || false,
      score: progress.score || null,
      completedAt: progress.completed ? new Date() : null,
    };
    
    this.userProgress.set(key, newProgress);
    return newProgress;
  }

  async getAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values()).filter(ua => ua.userId === userId);
  }

  async addUserAchievement(userId: number, achievementId: number): Promise<UserAchievement> {
    const key = `${userId}-${achievementId}`;
    const existingAchievement = this.userAchievements.get(key);
    
    if (existingAchievement) {
      return existingAchievement;
    }
    
    const newUserAchievement: UserAchievement = {
      id: this.currentAchievementId++,
      userId,
      achievementId,
      earnedAt: new Date(),
    };
    
    this.userAchievements.set(key, newUserAchievement);
    return newUserAchievement;
  }

  private initializeData() {
    // Initialize lesson categories
    const categories: LessonCategory[] = [
      { id: 1, name: "Stock Market Safari", description: "Join Captain Cash on an adventure to understand how companies sell tiny pieces of themselves and how you can own them too!", color: "green", icon: "fas fa-chart-line", order: 1 },
      { id: 2, name: "Day Trading Detectives", description: "Explore with Flash the Fox how some people buy and sell stocks super fast - and why it's risky business!", color: "red", icon: "fas fa-bolt", order: 2 },
      { id: 3, name: "Career Cash Academy", description: "Discover with Professor Success how to find amazing jobs, write resumes, and ace interviews to earn money!", color: "blue", icon: "fas fa-briefcase", order: 3 },
      { id: 4, name: "Free Fun Financial Club", description: "Learn with Thrifty the Turtle about amazing free activities and money-saving hacks that keep cash in your pocket!", color: "green", icon: "fas fa-leaf", order: 4 },
      { id: 5, name: "Home Buying Heroes", description: "Learn with Ruby the Realtor about mortgages, down payments, and how adults buy their dream homes!", color: "orange", icon: "fas fa-home", order: 5 },
    ];

    categories.forEach(category => {
      this.lessonCategories.set(category.id, category);
    });

    // Initialize lessons with premium content
    const lessonData: Lesson[] = [
      { 
        id: 1, 
        categoryId: 1, 
        title: "What Are Stocks?", 
        description: "Captain Cash explains how companies sell shares to raise money!", 
        content: { 
          type: "interactive", 
          character: "Captain Cash", 
          sections: [
            {
              type: "intro",
              title: "Welcome Young Investor!",
              content: "Ahoy there! I'm Captain Cash, and today we're going on a treasure hunt to learn about stocks!"
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 15,
        isPremium: false,
        requiredTier: "free"
      },
      { 
        id: 2, 
        categoryId: 1, 
        title: "Advanced Stock Analysis", 
        description: "Premium lesson: Learn professional stock evaluation techniques!", 
        content: { 
          type: "interactive", 
          character: "Captain Cash", 
          sections: [
            {
              type: "intro",
              title: "Advanced Investment Strategies",
              content: "Welcome to the premium content! Learn how professional investors analyze stocks using P/E ratios, market cap, and more!"
            }
          ]
        }, 
        order: 2, 
        estimatedMinutes: 25,
        isPremium: true,
        requiredTier: "premium"
      },
      { 
        id: 3, 
        categoryId: 2, 
        title: "Day Trading Basics", 
        description: "Flash the Fox explains the risks of quick stock trading!", 
        content: { 
          type: "interactive", 
          character: "Flash the Fox", 
          sections: [
            {
              type: "intro",
              title: "Super Fast Trading!",
              content: "Hi there! I'm Flash the Fox, and I'm REALLY fast! But day trading is risky!"
            }
          ]
        }, 
        order: 1, 
        estimatedMinutes: 18,
        isPremium: false,
        requiredTier: "free"
      },
      { 
        id: 4, 
        categoryId: 2, 
        title: "Professional Trading Strategies", 
        description: "Premium: Advanced day trading techniques and risk management!", 
        content: { 
          type: "interactive", 
          character: "Flash the Fox", 
          sections: [
            {
              type: "intro",
              title: "Professional Trading Techniques",
              content: "Premium content: Learn stop-loss orders, technical analysis, and professional risk management strategies!"
            }
          ]
        }, 
        order: 2, 
        estimatedMinutes: 30,
        isPremium: true,
        requiredTier: "premium"
      }
    ];

    lessonData.forEach(lesson => {
      this.lessons.set(lesson.id, lesson);
    });

    // Initialize achievements
    const achievementData: Achievement[] = [
      { id: 1, name: "Stock Market Explorer", description: "Completed your first stock market lesson!", icon: "fas fa-chart-line", color: "green", requirement: "Complete 1 stock lesson" },
      { id: 2, name: "Day Trading Detective", description: "Learned about the risks of day trading!", icon: "fas fa-bolt", color: "red", requirement: "Complete day trading lesson" },
      { id: 3, name: "Premium Learner", description: "Unlocked premium content!", icon: "fas fa-crown", color: "gold", requirement: "Subscribe to premium" },
    ];

    achievementData.forEach(achievement => {
      this.achievements.set(achievement.id, achievement);
    });
  }
}

export const storage = new MemStorage();