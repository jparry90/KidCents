import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Crown, Zap } from "lucide-react";
import Header from "../components/header";
import { useLocation } from "wouter";

const pricingPlans = [
  {
    name: "Free Explorer",
    price: 0,
    period: "forever",
    description: "Perfect for getting started with basic financial education",
    features: [
      "Access to 8 basic lessons",
      "Simple savings calculator",
      "Basic achievement badges",
      "Progress tracking",
      "Parent dashboard (limited)"
    ],
    limitations: [
      "No advanced investing lessons",
      "No premium calculators",
      "Limited character interactions"
    ],
    buttonText: "Get Started Free",
    popular: false,
    tier: "free"
  },
  {
    name: "Premium Learner",
    price: 9.99,
    period: "month",
    description: "Complete financial education with advanced tools and content",
    features: [
      "Access to ALL 16 lessons",
      "Advanced investing & trading lessons",
      "Interactive savings simulator",
      "Premium achievement system",
      "Animated character dialogues",
      "Enhanced quiz feedback",
      "Completion celebrations",
      "Full parent dashboard",
      "Priority customer support",
      "Monthly financial challenges"
    ],
    limitations: [],
    buttonText: "Start Premium",
    popular: true,
    tier: "premium"
  },
  {
    name: "Family Plan",
    price: 19.99,
    period: "month",
    description: "Perfect for families with multiple children learning together",
    features: [
      "Everything in Premium",
      "Up to 5 child accounts",
      "Family progress dashboard",
      "Shared achievement gallery",
      "Family financial challenges",
      "Advanced parental controls",
      "Custom savings goals",
      "Monthly family reports",
      "Priority support",
      "Early access to new content"
    ],
    limitations: [],
    buttonText: "Choose Family Plan",
    popular: false,
    tier: "family"
  }
];

export default function Pricing() {
  const [, setLocation] = useLocation();

  const handleSubscribe = (tier: string) => {
    if (tier === "free") {
      setLocation("/");
    } else {
      setLocation(`/subscribe?plan=${tier}`);
    }
  };

  return (
    <div className="min-h-screen bg-primary-green">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h1 className="font-fredoka text-5xl text-white mb-4">
            Choose Your Financial Learning Adventure
          </h1>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Start with our free lessons or unlock the complete financial education experience with premium features, advanced tools, and comprehensive content.
          </p>
          
          {/* Money-back guarantee badge */}
          <div className="inline-flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-6 py-3">
            <Star className="w-5 h-5 text-yellow-300 fill-current" />
            <span className="text-white font-semibold">30-day money-back guarantee</span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {pricingPlans.map((plan, index) => (
            <Card 
              key={index}
              className={`
                relative rounded-3xl shadow-xl transition-all duration-300 hover:scale-105
                ${plan.popular ? 'ring-4 ring-yellow-400 bg-white' : 'bg-white'}
              `}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-500 text-yellow-900 px-4 py-2 font-bold">
                    <Crown className="w-4 h-4 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardContent className="p-8">
                {/* Plan Header */}
                <div className="text-center mb-8">
                  <h3 className="font-fredoka text-2xl text-gray-800 mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-gray-900">${plan.price}</span>
                    {plan.price > 0 && <span className="text-gray-600">/{plan.period}</span>}
                  </div>
                  <p className="text-gray-600">{plan.description}</p>
                </div>

                {/* Features List */}
                <div className="mb-8">
                  <h4 className="font-semibold text-gray-800 mb-4">What's included:</h4>
                  <ul className="space-y-3">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start space-x-3">
                        <Check className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Button */}
                <Button
                  onClick={() => handleSubscribe(plan.tier)}
                  className={`
                    w-full py-4 font-bold text-lg rounded-2xl transition-all duration-200
                    ${plan.popular 
                      ? 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white' 
                      : 'bg-primary-green hover:bg-primary-green-dark text-white'
                    }
                  `}
                >
                  {plan.buttonText}
                </Button>

                {/* Additional Info */}
                {plan.price > 0 && (
                  <p className="text-center text-xs text-gray-500 mt-4">
                    Cancel anytime • No long-term contracts
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Feature Comparison */}
        <div className="bg-white rounded-3xl p-8 shadow-xl">
          <h2 className="font-fredoka text-3xl text-center text-gray-800 mb-8">
            Compare All Features
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-4 px-4 font-semibold text-gray-800">Features</th>
                  <th className="text-center py-4 px-4 font-semibold text-gray-800">Free</th>
                  <th className="text-center py-4 px-4 font-semibold text-gray-800">Premium</th>
                  <th className="text-center py-4 px-4 font-semibold text-gray-800">Family</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: "Basic financial lessons", free: true, premium: true, family: true },
                  { feature: "Advanced investing lessons", free: false, premium: true, family: true },
                  { feature: "Interactive calculators", free: "Basic", premium: "Advanced", family: "Advanced" },
                  { feature: "Character interactions", free: false, premium: true, family: true },
                  { feature: "Achievement system", free: "Basic", premium: "Complete", family: "Complete" },
                  { feature: "Parent dashboard", free: "Limited", premium: "Full", family: "Advanced" },
                  { feature: "Child accounts", free: "1", premium: "1", family: "5" },
                  { feature: "Priority support", free: false, premium: true, family: true },
                  { feature: "Monthly challenges", free: false, premium: true, family: true },
                ].map((row, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-4 px-4 text-gray-700">{row.feature}</td>
                    <td className="text-center py-4 px-4">
                      {typeof row.free === 'boolean' ? 
                        (row.free ? <Check className="w-5 h-5 text-green-600 mx-auto" /> : <span className="text-gray-400">—</span>) :
                        <span className="text-gray-600">{row.free}</span>
                      }
                    </td>
                    <td className="text-center py-4 px-4">
                      {typeof row.premium === 'boolean' ? 
                        (row.premium ? <Check className="w-5 h-5 text-green-600 mx-auto" /> : <span className="text-gray-400">—</span>) :
                        <span className="text-gray-600">{row.premium}</span>
                      }
                    </td>
                    <td className="text-center py-4 px-4">
                      {typeof row.family === 'boolean' ? 
                        (row.family ? <Check className="w-5 h-5 text-green-600 mx-auto" /> : <span className="text-gray-400">—</span>) :
                        <span className="text-gray-600">{row.family}</span>
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 text-center">
          <h2 className="font-fredoka text-3xl text-white mb-8">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                q: "Can I cancel my subscription anytime?",
                a: "Yes! You can cancel your subscription at any time with no cancellation fees. You'll continue to have access until your current billing period ends."
              },
              {
                q: "Is there a free trial for premium features?",
                a: "All premium plans come with a 30-day money-back guarantee, so you can try all features risk-free."
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept all major credit cards, debit cards, and digital wallets through our secure Stripe payment processing."
              },
              {
                q: "How does the Family Plan work?",
                a: "The Family Plan allows up to 5 child accounts under one subscription, with a unified parent dashboard to track all children's progress."
              }
            ].map((faq, index) => (
              <Card key={index} className="bg-white bg-opacity-10 border-white border-opacity-20">
                <CardContent className="p-6 text-left">
                  <h4 className="font-semibold text-white mb-2">{faq.q}</h4>
                  <p className="text-green-100 text-sm">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}