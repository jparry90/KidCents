import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
// Remove useSearchParams import
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Shield, CreditCard } from "lucide-react";
import Header from "../components/header";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const planDetails = {
  premium: {
    name: "Premium Learner",
    price: 9.99,
    features: [
      "Access to ALL 16 lessons",
      "Interactive savings simulator",
      "Animated character dialogues",
      "Enhanced quiz feedback",
      "Full parent dashboard"
    ]
  },
  family: {
    name: "Family Plan",
    price: 19.99,
    features: [
      "Everything in Premium",
      "Up to 5 child accounts",
      "Family progress dashboard",
      "Advanced parental controls",
      "Priority support"
    ]
  }
};

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!stripe || !elements) {
      setIsLoading(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/dashboard?subscribed=true`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Welcome to MoneyBuddies Premium!",
      });
    }
    setIsLoading(false);
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardContent className="p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Shield className="w-6 h-6 text-green-600" />
          <span className="text-sm text-gray-600">Secure payment powered by Stripe</span>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <PaymentElement />
          
          <Button 
            type="submit" 
            disabled={!stripe || isLoading}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-bold py-3 rounded-2xl"
          >
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                <span>Processing...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <CreditCard className="w-4 h-4" />
                <span>Complete Subscription</span>
              </div>
            )}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>By subscribing, you agree to our Terms of Service and Privacy Policy.</p>
          <p className="mt-2">Cancel anytime • 30-day money-back guarantee</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");
  const [selectedPlan, setSelectedPlan] = useState("premium");
  const searchParams = new URLSearchParams(window.location.search);
  const planFromUrl = searchParams.get('plan');

  useEffect(() => {
    const plan = planFromUrl || "premium";
    setSelectedPlan(plan);
    
    // Create subscription with the selected plan
    apiRequest("POST", "/api/create-subscription", { 
      plan,
      priceId: plan === "premium" ? "price_premium_monthly" : "price_family_monthly"
    })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
      })
      .catch((error) => {
        console.error("Error creating subscription:", error);
      });
  }, [planFromUrl]);

  const currentPlan = planDetails[selectedPlan as keyof typeof planDetails];

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-primary-green">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16">
          <div className="text-center">
            <div className="animate-spin w-12 h-12 border-4 border-white border-t-transparent rounded-full mx-auto mb-4" />
            <h2 className="font-fredoka text-2xl text-white">Setting up your subscription...</h2>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-primary-green">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="font-fredoka text-4xl text-white mb-4">
            Complete Your MoneyBuddies Subscription
          </h1>
          <p className="text-lg text-green-100">
            You're just one step away from unlocking premium financial education!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Plan Summary */}
          <div>
            <Card className="bg-white rounded-3xl shadow-xl">
              <CardContent className="p-8">
                <div className="flex items-center space-x-3 mb-6">
                  <Crown className="w-8 h-8 text-yellow-500" />
                  <div>
                    <h3 className="font-fredoka text-2xl text-gray-800">{currentPlan.name}</h3>
                    <div className="flex items-center space-x-2">
                      <span className="text-3xl font-bold text-gray-900">${currentPlan.price}</span>
                      <span className="text-gray-600">/month</span>
                      <Badge className="bg-green-100 text-green-800">Best Value</Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  <h4 className="font-semibold text-gray-800">What you'll get:</h4>
                  <ul className="space-y-3">
                    {currentPlan.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                          <svg className="w-3 h-3 text-white" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-green-50 rounded-2xl p-4">
                  <h4 className="font-semibold text-green-800 mb-2">30-Day Money-Back Guarantee</h4>
                  <p className="text-green-700 text-sm">
                    Try MoneyBuddies Premium risk-free. If you're not completely satisfied, 
                    we'll refund your payment within 30 days.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Form */}
          <div>
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <SubscribeForm />
            </Elements>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <div className="flex justify-center items-center space-x-8 text-white opacity-75">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5" />
              <span className="text-sm">SSL Secured</span>
            </div>
            <div className="flex items-center space-x-2">
              <CreditCard className="w-5 h-5" />
              <span className="text-sm">Stripe Protected</span>
            </div>
            <div className="flex items-center space-x-2">
              <Crown className="w-5 h-5" />
              <span className="text-sm">Cancel Anytime</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}