import Header from "../components/header";
import HeroSection from "../components/hero-section";
import LessonCategories from "../components/lesson-categories";
import SampleLesson from "../components/sample-lesson";
import Achievements from "../components/achievements";
import ParentDashboard from "../components/parent-dashboard";
import GamifiedProgressTracker from "../components/gamified-progress-tracker";
import Footer from "../components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-primary-green">
      <Header />
      <HeroSection />
      <LessonCategories />
      
      {/* Enhanced Progress Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="font-fredoka text-4xl text-gray-800 mb-4">Your Learning Dashboard</h3>
            <p className="text-lg text-gray-600">Track your financial education journey with detailed progress insights!</p>
          </div>
          <div className="max-w-4xl mx-auto">
            <GamifiedProgressTracker
              currentLesson={8}
              totalLessons={16}
              completedLessons={8}
              currentStreak={7}
              totalBadges={3}
              weeklyGoal={5}
              weeklyProgress={3}
            />
          </div>
        </div>
      </section>
      
      <SampleLesson />
      <Achievements />
      <ParentDashboard />
      <Footer />
    </div>
  );
}
