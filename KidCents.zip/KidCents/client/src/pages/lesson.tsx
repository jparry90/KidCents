import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import Header from "../components/header";
import PremiumContentGate from "@/components/premium-content-gate";
import { ArrowLeft, ArrowRight, Calculator, Trophy, Star, CheckCircle, X } from "lucide-react";
import type { Lesson } from "@shared/schema";
import { useState } from "react";

export default function Lesson() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const lessonId = params.id ? parseInt(params.id) : 0;
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  
  // Calculator state
  const [savingGoal, setSavingGoal] = useState("");
  const [goalCost, setGoalCost] = useState("");
  const [weeklyAmount, setWeeklyAmount] = useState("");
  const [calculationResult, setCalculationResult] = useState<string | null>(null);
  const [completedSections, setCompletedSections] = useState<boolean[]>([]);
  const [showCelebration, setShowCelebration] = useState(false);

  const { data: lesson, isLoading } = useQuery<Lesson>({
    queryKey: ["/api/lessons", lessonId],
  });

  if (isLoading) {
    return (
      <div className="bg-primary-green min-h-screen">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-green-200 rounded w-1/3 mb-4"></div>
            <div className="h-64 bg-green-200 rounded mb-4"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!lesson && !isLoading) {
    return (
      <div className="bg-primary-green min-h-screen">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="bg-green-100 rounded-3xl p-8 text-center">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Lesson Not Found</h1>
            <p className="text-gray-600">The lesson you're looking for doesn't exist.</p>
          </div>
        </div>
      </div>
    );
  }

  // Check if lesson is premium and user doesn't have access
  const isPremium = (lesson as any)?.isPremium || false;
  const requiredTier = (lesson as any)?.requiredTier || "free";
  const userTier = "free"; // In a real app, get this from user state/context
  
  if (isPremium && userTier === "free") {
    return (
      <div className="bg-primary-green min-h-screen">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="mb-6">
            <Button 
              onClick={() => setLocation("/")}
              className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm border border-white/30"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
          <PremiumContentGate
            title={lesson?.title || "Premium Lesson"}
            description={lesson?.description || "This lesson requires a premium subscription."}
            requiredTier={requiredTier as "premium" | "family"}
          />
        </div>
      </div>
    );
  }

  const sections = (lesson?.content as any)?.sections || [];
  const currentSection = sections[currentSectionIndex];
  const totalSections = sections.length;
  const progress = totalSections > 0 ? ((currentSectionIndex + 1) / totalSections) * 100 : 0;

  const handlePrevious = () => {
    if (currentSectionIndex > 0) {
      setCurrentSectionIndex(currentSectionIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentSectionIndex < totalSections - 1) {
      setCurrentSectionIndex(currentSectionIndex + 1);
    } else {
      // Navigate to home page when lesson is complete
      setLocation("/");
    }
  };

  const handleAnswerSelect = (optionIndex: number) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [currentSectionIndex]: optionIndex
    });
  };

  const isAnswerCorrect = (sectionIndex: number, optionIndex: number) => {
    const section = sections[sectionIndex];
    return section?.correct === optionIndex;
  };

  const hasAnswered = selectedAnswers.hasOwnProperty(currentSectionIndex);

  const calculateSavingPlan = () => {
    const cost = parseFloat(goalCost);
    const weekly = parseFloat(weeklyAmount);
    
    if (isNaN(cost) || isNaN(weekly) || cost <= 0 || weekly <= 0) {
      setCalculationResult("Please enter valid positive numbers for both cost and weekly savings!");
      return;
    }
    
    const weeksNeeded = Math.ceil(cost / weekly);
    const totalSaved = weeksNeeded * weekly;
    const extraSaved = totalSaved - cost;
    
    let result = `Great plan! You'll reach your goal in ${weeksNeeded} weeks`;
    if (weeksNeeded <= 4) {
      result += " (about 1 month)";
    } else if (weeksNeeded <= 12) {
      result += ` (about ${Math.ceil(weeksNeeded / 4)} months)`;
    } else {
      result += ` (about ${Math.ceil(weeksNeeded / 52)} year${weeksNeeded > 52 ? 's' : ''})`;
    }
    
    result += `! You'll save $${totalSaved.toFixed(2)} total.`;
    if (extraSaved > 0) {
      result += ` That's $${extraSaved.toFixed(2)} extra for your next goal!`;
    }
    
    setCalculationResult(result);
  };

  const isCalculatorActivity = currentSection?.title?.toLowerCase().includes('saving') || 
                            currentSection?.title?.toLowerCase().includes('calculator') ||
                            currentSection?.title?.toLowerCase().includes('plan');

  // Character visual mapping
  const getCharacterVisual = (characterName: string) => {
    const characterMap: { [key: string]: { icon: string; bgColor: string } } = {
      "Captain Cash": { icon: "fas fa-coins", bgColor: "bg-green-500" },
      "Flash the Fox": { icon: "fas fa-bolt", bgColor: "bg-red-500" },
      "Professor Success": { icon: "fas fa-graduation-cap", bgColor: "bg-blue-500" },
      "Thrifty the Turtle": { icon: "fas fa-leaf", bgColor: "bg-green-600" },
      "Ruby the Realtor": { icon: "fas fa-home", bgColor: "bg-orange-500" },
      "Wise Owl Winston": { icon: "fas fa-owl", bgColor: "bg-purple-500" },
      "Detective Dollar": { icon: "fas fa-search-dollar", bgColor: "bg-indigo-500" },
      "Captain Credit": { icon: "fas fa-credit-card", bgColor: "bg-blue-600" },
      "Sage the Eagle": { icon: "fas fa-mountain", bgColor: "bg-yellow-600" },
      "Shield the Guardian": { icon: "fas fa-shield-alt", bgColor: "bg-gray-600" },
      "Crusher the Rhino": { icon: "fas fa-hammer", bgColor: "bg-red-600" },
      "Boss the Lion": { icon: "fas fa-crown", bgColor: "bg-yellow-500" },
      "Tax Master Tim": { icon: "fas fa-calculator", bgColor: "bg-teal-500" }
    };
    
    return characterMap[characterName] || { icon: "fas fa-user-circle", bgColor: "bg-primary-green" };
  };

  const characterInfo = getCharacterVisual((lesson?.content as any)?.character || "Financial Expert");

  return (
    <div className="bg-primary-green min-h-screen">
      <Header />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-green-100 shadow-2xl rounded-3xl p-8">
            {/* Lesson header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <div className={`w-16 h-16 ${characterInfo.bgColor} rounded-2xl flex items-center justify-center`}>
                  <i className={`${characterInfo.icon} text-white text-2xl`}></i>
                </div>
                <div>
                  <h1 className="font-fredoka text-3xl text-gray-800">{lesson?.title}</h1>
                  <p className="text-gray-600">{lesson?.description}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500 mb-1">Progress</div>
                <Progress value={progress} className="w-32" />
                <div className="text-xs text-gray-500 mt-1">
                  {currentSectionIndex + 1} of {totalSections}
                </div>
              </div>
            </div>

            {/* Lesson content */}
            <div className="grid lg:grid-cols-2 gap-8">
              <div>
                {/* Character explaining concept */}
                <div className="bg-primary-green bg-opacity-10 rounded-2xl p-6 mb-6">
                  <div className="flex items-start space-x-4">
                    <div className={`w-16 h-16 ${characterInfo.bgColor} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <i className={`${characterInfo.icon} text-white text-2xl`}></i>
                    </div>
                    <div>
                      <h2 className="font-bold text-primary-green-dark mb-2">
                        {(lesson?.content as any)?.character || "Financial Expert"} says:
                      </h2>
                      {currentSection && (
                        <div className="mb-4">
                          <h3 className="font-semibold text-gray-800 mb-2">{currentSection.title}</h3>
                          <p className="text-gray-700 leading-relaxed">{currentSection.content}</p>
                          {currentSection.type === 'quiz' && currentSection.question && (
                            <div className="mt-4 p-4 bg-green-100 rounded-xl">
                              <p className="font-semibold text-gray-800 mb-3">{currentSection.question}</p>
                              <div className="space-y-2">
                                {currentSection.options?.map((option: string, optIndex: number) => {
                                  const isSelected = selectedAnswers[currentSectionIndex] === optIndex;
                                  const isCorrect = isAnswerCorrect(currentSectionIndex, optIndex);
                                  const showResult = hasAnswered;
                                  
                                  let buttonClass = "block w-full text-left p-3 rounded-lg border-2 transition-all ";
                                  
                                  if (showResult) {
                                    if (isSelected && isCorrect) {
                                      buttonClass += "border-green-500 bg-green-500 text-white";
                                    } else if (isSelected && !isCorrect) {
                                      buttonClass += "border-red-500 bg-red-500 text-white";
                                    } else if (isCorrect) {
                                      buttonClass += "border-green-500 bg-green-100 text-green-800";
                                    } else {
                                      buttonClass += "border-gray-200 bg-gray-100 text-gray-600";
                                    }
                                  } else {
                                    buttonClass += "border-gray-200 hover:border-primary-green hover:bg-primary-green hover:text-white";
                                  }
                                  
                                  return (
                                    <button 
                                      key={optIndex}
                                      onClick={() => !hasAnswered && handleAnswerSelect(optIndex)}
                                      disabled={hasAnswered}
                                      className={buttonClass}
                                    >
                                      {option}
                                    </button>
                                  );
                                })}
                              </div>
                              {hasAnswered && (
                                <div className="mt-3 p-3 rounded-lg bg-blue-50">
                                  <p className="text-sm text-blue-800">
                                    {isAnswerCorrect(currentSectionIndex, selectedAnswers[currentSectionIndex]) 
                                      ? "🎉 Correct! Great job!" 
                                      : `❌ Not quite right. The correct answer is: "${currentSection.options[currentSection.correct]}"`}
                                  </p>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Interactive activity */}
                {currentSection && currentSection.type === 'activity' && (
                  <div className="bg-accent-yellow bg-opacity-20 rounded-2xl p-6">
                    <h3 className="font-bold text-gray-800 mb-4">{currentSection.title}</h3>
                    <div className="bg-green-100 rounded-xl p-4 mb-4">
                      <p className="text-gray-700 whitespace-pre-line">{currentSection.content}</p>
                    </div>
                    
                    {/* Interactive Calculator for Saving Plans */}
                    {isCalculatorActivity && (
                      <div className="bg-white rounded-xl p-6 border-2 border-green-200">
                        <div className="flex items-center mb-4">
                          <Calculator className="w-6 h-6 text-primary-green mr-2" />
                          <h4 className="font-bold text-gray-800">Saving Plan Calculator</h4>
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              What do you want to save for?
                            </label>
                            <input 
                              type="text" 
                              value={savingGoal}
                              onChange={(e) => setSavingGoal(e.target.value)}
                              placeholder="A new bike, toy, or game!" 
                              className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-primary-green focus:outline-none"
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                How much does it cost?
                              </label>
                              <input 
                                type="number" 
                                value={goalCost}
                                onChange={(e) => setGoalCost(e.target.value)}
                                placeholder="50" 
                                min="0"
                                step="0.01"
                                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-primary-green focus:outline-none"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                How much can you save per week?
                              </label>
                              <input 
                                type="number" 
                                value={weeklyAmount}
                                onChange={(e) => setWeeklyAmount(e.target.value)}
                                placeholder="5" 
                                min="0"
                                step="0.01"
                                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-primary-green focus:outline-none"
                              />
                            </div>
                          </div>
                          
                          <Button 
                            onClick={calculateSavingPlan}
                            className="w-full bg-primary-green text-white hover:bg-primary-green-dark"
                            disabled={!goalCost || !weeklyAmount}
                          >
                            Calculate My Saving Plan!
                          </Button>
                          
                          {calculationResult && (
                            <div className="mt-4 p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                              <div className="flex items-start">
                                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mr-3">
                                  <span className="text-white text-sm">💡</span>
                                </div>
                                <div>
                                  <h5 className="font-semibold text-blue-800 mb-1">Your Saving Plan:</h5>
                                  <p className="text-blue-700">{calculationResult}</p>
                                  {savingGoal && (
                                    <p className="text-blue-600 text-sm mt-2">
                                      Keep saving for your {savingGoal}! You've got this! 🎯
                                    </p>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div>
                {/* Visual representation */}
                <div className="text-center">
                  <div className={`w-full h-64 bg-gradient-to-br ${characterInfo.bgColor} to-opacity-80 rounded-2xl shadow-lg mb-6 flex items-center justify-center`}>
                    <i className={`${characterInfo.icon} text-white text-8xl`}></i>
                  </div>
                  
                  {/* Progress visualization */}
                  <div className="bg-green-100 rounded-2xl p-6">
                    <h3 className="font-bold text-gray-800 mb-4">Lesson Progress</h3>
                    <div className="space-y-3">
                      {sections.map((section: any, index: number) => (
                        <div key={index} className="flex items-center justify-between">
                          <span className="text-sm">{section.title}</span>
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            index < currentSectionIndex 
                              ? 'bg-primary-green' 
                              : index === currentSectionIndex 
                                ? 'bg-primary-orange' 
                                : 'bg-gray-300'
                          }`}>
                            <span className="text-white text-xs">
                              {index < currentSectionIndex ? '✓' : index + 1}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Lesson navigation */}
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
              <Button 
                variant="outline" 
                className="text-gray-700"
                onClick={handlePrevious}
                disabled={currentSectionIndex === 0}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <div className="flex space-x-2">
                {sections.map((_: any, index: number) => (
                  <div 
                    key={index}
                    className={`w-3 h-3 rounded-full ${
                      index <= currentSectionIndex ? 'bg-primary-green' : 'bg-gray-300'
                    }`}
                  ></div>
                ))}
              </div>
              <Button 
                className="bg-primary-orange hover:bg-primary-orange-dark text-white"
                onClick={handleNext}
                disabled={currentSection?.type === 'quiz' && !hasAnswered}
              >
                {currentSectionIndex === totalSections - 1 ? 'Complete' : 'Next'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
        </div>
      </div>
    </div>
  );
}
