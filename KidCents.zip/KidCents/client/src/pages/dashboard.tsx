import Header from "../components/header";
import ParentDashboard from "../components/parent-dashboard";
import Footer from "../components/footer";

export default function Dashboard() {
  return (
    <div className="bg-bg-cream min-h-screen">
      <Header />
      <div className="py-8">
        <ParentDashboard />
      </div>
      <Footer />
    </div>
  );
}
