import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Crown, Clock, Star, Trophy, Medal, Award } from "lucide-react";

interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  color: string;
  requirement: string;
  isEarned: boolean;
  progress: number;
  maxProgress: number;
  rarity: "common" | "rare" | "epic" | "legendary";
}

interface EnhancedAchievementsProps {
  achievements: Achievement[];
}

export default function EnhancedAchievements({ achievements }: EnhancedAchievementsProps) {
  const getRarityColors = (rarity: string) => {
    switch (rarity) {
      case "legendary": return "from-yellow-500 to-orange-500";
      case "epic": return "from-purple-500 to-pink-500";
      case "rare": return "from-blue-500 to-cyan-500";
      default: return "from-gray-400 to-gray-500";
    }
  };

  const getRarityIcon = (rarity: string) => {
    switch (rarity) {
      case "legendary": return <Crown className="w-4 h-4" />;
      case "epic": return <Trophy className="w-4 h-4" />;
      case "rare": return <Medal className="w-4 h-4" />;
      default: return <Award className="w-4 h-4" />;
    }
  };

  return (
    <section className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="font-fredoka text-4xl text-gray-800 mb-4">Achievement Showcase</h3>
          <p className="text-lg text-gray-600">Unlock awesome badges by completing financial lessons!</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {achievements.map((achievement) => (
            <Card 
              key={achievement.id} 
              className={`relative overflow-hidden transition-all duration-300 hover:scale-105 ${
                achievement.isEarned ? 'shadow-lg border-2' : 'opacity-70 filter grayscale'
              }`}
            >
              <CardContent className="p-6 text-center">
                {/* Rarity Indicator */}
                <div className={`absolute top-2 right-2 w-8 h-8 rounded-full bg-gradient-to-r ${getRarityColors(achievement.rarity)} flex items-center justify-center text-white`}>
                  {getRarityIcon(achievement.rarity)}
                </div>
                
                {/* Achievement Status */}
                {achievement.isEarned && (
                  <div className="absolute top-2 left-2 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                    <Star className="w-4 h-4 text-white fill-current" />
                  </div>
                )}
                
                {/* Icon */}
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                  achievement.isEarned 
                    ? `bg-gradient-to-r ${getRarityColors(achievement.rarity)}` 
                    : 'bg-gray-300'
                }`}>
                  <i className={`${achievement.icon} text-2xl ${achievement.isEarned ? 'text-white' : 'text-gray-500'}`}></i>
                </div>
                
                {/* Title */}
                <h4 className="font-fredoka text-lg font-bold text-gray-800 mb-2">
                  {achievement.name}
                </h4>
                
                {/* Description */}
                <p className="text-sm text-gray-600 mb-3">
                  {achievement.description}
                </p>
                
                {/* Progress Bar */}
                {!achievement.isEarned && achievement.progress > 0 && (
                  <div className="mb-3">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {achievement.progress}/{achievement.maxProgress}
                    </p>
                  </div>
                )}
                
                {/* Rarity Badge */}
                <Badge 
                  className={`${achievement.isEarned ? 'bg-gradient-to-r' : 'bg-gray-300'} ${getRarityColors(achievement.rarity)} text-white border-0 text-xs`}
                >
                  {achievement.rarity.toUpperCase()}
                </Badge>
                
                {/* Time-based indicator for recent achievements */}
                {achievement.isEarned && (
                  <div className="absolute bottom-2 right-2 flex items-center text-xs text-gray-500">
                    <Clock className="w-3 h-3 mr-1" />
                    <span>New!</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Achievement Stats */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center space-x-8 bg-white rounded-2xl px-8 py-4 shadow-lg">
            <div>
              <div className="text-2xl font-bold text-green-600">
                {achievements.filter(a => a.isEarned).length}
              </div>
              <div className="text-sm text-gray-600">Earned</div>
            </div>
            <div className="w-px h-8 bg-gray-200"></div>
            <div>
              <div className="text-2xl font-bold text-blue-600">
                {achievements.length}
              </div>
              <div className="text-sm text-gray-600">Total</div>
            </div>
            <div className="w-px h-8 bg-gray-200"></div>
            <div>
              <div className="text-2xl font-bold text-purple-600">
                {Math.round((achievements.filter(a => a.isEarned).length / achievements.length) * 100)}%
              </div>
              <div className="text-sm text-gray-600">Complete</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}