import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Clock, Star, Target } from "lucide-react";

interface EnhancedLessonHeaderProps {
  lessonTitle: string;
  lessonDescription: string;
  characterIcon: string;
  characterColor: string;
  currentSection: number;
  totalSections: number;
  estimatedMinutes: number;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
}

export default function EnhancedLessonHeader({
  lessonTitle,
  lessonDescription,
  characterIcon,
  characterColor,
  currentSection,
  totalSections,
  estimatedMinutes,
  difficulty
}: EnhancedLessonHeaderProps) {
  const progress = ((currentSection + 1) / totalSections) * 100;
  
  const difficultyColors = {
    "Beginner": "bg-green-100 text-green-800",
    "Intermediate": "bg-yellow-100 text-yellow-800", 
    "Advanced": "bg-red-100 text-red-800"
  };

  return (
    <div className="bg-gradient-to-r from-white to-gray-50 rounded-3xl p-8 shadow-xl border border-gray-200">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center space-x-6">
          {/* Character Avatar */}
          <div className={`w-20 h-20 bg-${characterColor}-500 rounded-2xl flex items-center justify-center shadow-lg`}>
            <i className={`${characterIcon} text-white text-3xl`}></i>
          </div>
          
          {/* Lesson Info */}
          <div>
            <h1 className="font-fredoka text-4xl text-gray-800 mb-2">{lessonTitle}</h1>
            <p className="text-lg text-gray-600 mb-3 max-w-2xl">{lessonDescription}</p>
            
            {/* Lesson Metadata */}
            <div className="flex items-center space-x-4">
              <Badge className={difficultyColors[difficulty]}>
                {difficulty}
              </Badge>
              <div className="flex items-center space-x-1 text-gray-500">
                <Clock className="w-4 h-4" />
                <span className="text-sm">{estimatedMinutes} min</span>
              </div>
              <div className="flex items-center space-x-1 text-gray-500">
                <Target className="w-4 h-4" />
                <span className="text-sm">{totalSections} sections</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Progress Circle */}
        <div className="text-center">
          <div className="relative w-20 h-20 mb-2">
            <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-gray-300"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className={`text-${characterColor}-500`}
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
                strokeDasharray={`${progress}, 100`}
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-xl font-bold text-gray-800">{Math.round(progress)}%</span>
            </div>
          </div>
          <p className="text-sm text-gray-500">Complete</p>
        </div>
      </div>
      
      {/* Section Progress Bar */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-semibold text-gray-800">Section Progress</h3>
          <span className="text-sm text-gray-600">
            {currentSection + 1} of {totalSections}
          </span>
        </div>
        <Progress value={progress} className="h-3" />
      </div>
      
      {/* Section Navigation Pills */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {Array.from({ length: totalSections }, (_, index) => (
          <div
            key={index}
            className={`
              flex-shrink-0 px-3 py-1 rounded-full text-xs font-medium
              ${index < currentSection ? 'bg-green-500 text-white' : 
                index === currentSection ? `bg-${characterColor}-500 text-white` : 
                'bg-gray-200 text-gray-600'}
            `}
          >
            {index + 1}
          </div>
        ))}
      </div>
    </div>
  );
}