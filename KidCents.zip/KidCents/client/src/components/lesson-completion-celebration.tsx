import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, Star, Gift, ArrowRight } from "lucide-react";

interface LessonCompletionCelebrationProps {
  lessonTitle: string;
  character: string;
  onContinue: () => void;
  onReturnHome: () => void;
}

export default function LessonCompletionCelebration({
  lessonTitle,
  character,
  onContinue,
  onReturnHome
}: LessonCompletionCelebrationProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 animate-fadeIn">
      <Card className="bg-gradient-to-br from-yellow-400 via-orange-500 to-pink-500 rounded-3xl shadow-2xl max-w-md mx-4">
        <CardContent className="p-8 text-center">
          {/* Celebration Animation */}
          <div className="mb-6 relative">
            <div className="w-24 h-24 mx-auto bg-white rounded-full flex items-center justify-center animate-bounce">
              <Trophy className="w-12 h-12 text-yellow-500" />
            </div>
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2">
              <div className="flex space-x-2">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className="w-4 h-4 text-yellow-300 fill-current animate-pulse" 
                    style={{ animationDelay: `${i * 0.1}s` }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Celebration Message */}
          <h2 className="font-fredoka text-3xl text-white mb-2">
            Congratulations!
          </h2>
          <p className="text-white text-lg mb-2">
            You completed "{lessonTitle}"!
          </p>
          <p className="text-white text-sm mb-6 opacity-90">
            {character} is proud of your progress! 🎉
          </p>

          {/* Reward Summary */}
          <div className="bg-white bg-opacity-20 rounded-2xl p-4 mb-6">
            <div className="flex items-center justify-center space-x-4">
              <div className="text-center">
                <Gift className="w-6 h-6 text-white mx-auto mb-1" />
                <p className="text-white text-xs">New Badge</p>
              </div>
              <div className="text-center">
                <Star className="w-6 h-6 text-white mx-auto mb-1 fill-current" />
                <p className="text-white text-xs">+50 Points</p>
              </div>
              <div className="text-center">
                <Trophy className="w-6 h-6 text-white mx-auto mb-1" />
                <p className="text-white text-xs">Achievement</p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col space-y-3">
            <Button 
              onClick={onContinue}
              className="bg-white text-orange-600 hover:bg-gray-100 font-bold py-3 rounded-2xl flex items-center justify-center space-x-2"
            >
              <span>Continue Learning</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button 
              onClick={onReturnHome}
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-orange-600 py-3 rounded-2xl"
            >
              Return to Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}