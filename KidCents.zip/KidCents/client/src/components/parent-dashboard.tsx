import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export default function ParentDashboard() {
  return (
    <section className="py-16 bg-primary-green">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="font-fredoka text-4xl text-white mb-4">For Parents & Teachers</h3>
          <p className="text-lg text-green-50">Track progress, set goals, and celebrate your child's financial learning journey!</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <Card className="bg-green-50 rounded-3xl shadow-xl">
            <CardContent className="p-8">
              <h4 className="font-bold text-2xl text-gray-800 mb-6">Progress Dashboard</h4>
              
              {/* Progress stats */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-primary-green bg-opacity-10 rounded-2xl p-4 text-center relative overflow-hidden transform hover:scale-105 transition-all duration-200">
                  <div className="absolute top-2 right-2">
                    <i className="fas fa-trophy text-primary-green text-lg opacity-20"></i>
                  </div>
                  <div className="flex items-center justify-center mb-1">
                    <div className="font-bold text-2xl text-primary-green-dark">8</div>
                    <div className="w-3 h-3 bg-primary-green rounded-full ml-2 animate-pulse"></div>
                  </div>
                  <div className="text-sm text-gray-600">Lessons Completed</div>
                  <div className="text-xs text-primary-green-dark mt-1 font-semibold">+2 this week!</div>
                  <div className="mt-2 bg-primary-green-dark bg-opacity-20 rounded-full h-2">
                    <div className="bg-primary-green-dark h-2 rounded-full w-1/2"></div>
                  </div>
                </div>
                <div className="bg-primary-orange bg-opacity-10 rounded-2xl p-4 text-center relative overflow-hidden">
                  <div className="absolute top-2 right-2">
                    <i className="fas fa-medal text-primary-orange text-lg opacity-20"></i>
                  </div>
                  <div className="font-bold text-2xl text-primary-orange-dark">3</div>
                  <div className="text-sm text-gray-600">Badges Earned</div>
                  <div className="text-xs text-primary-orange-dark mt-1">Next: Day Trading Detective</div>
                </div>
                <div className="bg-accent-yellow bg-opacity-10 rounded-2xl p-4 text-center relative overflow-hidden">
                  <div className="absolute top-2 right-2">
                    <i className="fas fa-clock text-yellow-600 text-lg opacity-20"></i>
                  </div>
                  <div className="font-bold text-2xl text-yellow-600">45</div>
                  <div className="text-sm text-gray-600">Minutes Learned</div>
                  <div className="text-xs text-yellow-600 mt-1">15 min today!</div>
                </div>
                <div className="bg-accent-pink bg-opacity-10 rounded-2xl p-4 text-center relative overflow-hidden">
                  <div className="absolute top-2 right-2">
                    <i className="fas fa-star text-pink-600 text-lg opacity-20"></i>
                  </div>
                  <div className="font-bold text-2xl text-pink-600">92%</div>
                  <div className="text-sm text-gray-600">Quiz Average</div>
                  <div className="text-xs text-pink-600 mt-1">Excellent work!</div>
                </div>
              </div>

              {/* Recent activity */}
              <h5 className="font-bold text-lg text-gray-800 mb-4">Recent Activity</h5>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-green-100 rounded-xl">
                  <div className="w-8 h-8 bg-primary-green rounded-full flex items-center justify-center">
                    <i className="fas fa-check text-white text-xs"></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Completed "Stock Market Basics"</p>
                    <p className="text-xs text-gray-500">2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-green-100 rounded-xl">
                  <div className="w-8 h-8 bg-accent-yellow rounded-full flex items-center justify-center">
                    <i className="fas fa-star text-white text-xs"></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Earned "Stock Market Explorer" badge</p>
                    <p className="text-xs text-gray-500">Yesterday</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 rounded-3xl shadow-xl">
            <CardContent className="p-8">
              <h4 className="font-bold text-2xl text-gray-800 mb-6">Parent Controls</h4>
              
              {/* Settings */}
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-green-100 rounded-xl">
                  <div>
                    <p className="font-medium text-gray-800">Daily time limit</p>
                    <p className="text-sm text-gray-600">Set learning time per day</p>
                  </div>
                  <Select defaultValue="30">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="45">45 minutes</SelectItem>
                      <SelectItem value="60">60 minutes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between p-4 bg-green-100 rounded-xl">
                  <div>
                    <p className="font-medium text-gray-800">Progress notifications</p>
                    <p className="text-sm text-gray-600">Get updates on achievements</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 bg-green-100 rounded-xl">
                  <div>
                    <p className="font-medium text-gray-800">Difficulty level</p>
                    <p className="text-sm text-gray-600">Adjust content complexity</p>
                  </div>
                  <Select defaultValue="beginner">
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner (5-7)</SelectItem>
                      <SelectItem value="intermediate">Intermediate (8-10)</SelectItem>
                      <SelectItem value="advanced">Advanced (11-13)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Quick actions */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h5 className="font-bold text-lg text-gray-800 mb-4">Quick Actions</h5>
                <div className="grid grid-cols-2 gap-3">
                  <Button className="bg-primary-green hover:bg-primary-green-dark text-white font-bold py-3 px-4 rounded-xl text-sm">
                    Email Report
                  </Button>
                  <Button className="bg-primary-orange hover:bg-primary-orange-dark text-white font-bold py-3 px-4 rounded-xl text-sm">
                    Set Goals
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}