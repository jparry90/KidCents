import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Star, Trophy, Target, Flame, Zap } from "lucide-react";

interface GamifiedProgressTrackerProps {
  currentLesson: number;
  totalLessons: number;
  completedLessons: number;
  currentStreak: number;
  totalBadges: number;
  weeklyGoal: number;
  weeklyProgress: number;
}

export default function GamifiedProgressTracker({
  currentLesson,
  totalLessons,
  completedLessons,
  currentStreak,
  totalBadges,
  weeklyGoal,
  weeklyProgress
}: GamifiedProgressTrackerProps) {
  const overallProgress = (completedLessons / totalLessons) * 100;
  const weeklyProgressPercent = (weeklyProgress / weeklyGoal) * 100;
  const xpPoints = completedLessons * 50 + currentStreak * 10;
  
  const levelInfo = {
    current: Math.floor(xpPoints / 200) + 1,
    xpInLevel: xpPoints % 200,
    xpToNext: 200 - (xpPoints % 200)
  };

  return (
    <div className="space-y-4">
      {/* Main Progress Card */}
      <Card className="bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-500 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-xl">Your Financial Journey</h3>
            <Badge variant="secondary" className="bg-white text-purple-600 font-bold">
              Level {levelInfo.current}
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {/* Lessons Progress */}
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Target className="w-6 h-6" />
              </div>
              <p className="text-2xl font-bold">{completedLessons}/{totalLessons}</p>
              <p className="text-sm opacity-90">Lessons</p>
            </div>
            
            {/* Current Streak */}
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-500 bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Flame className="w-6 h-6 text-orange-300" />
              </div>
              <p className="text-2xl font-bold">{currentStreak}</p>
              <p className="text-sm opacity-90">Day Streak</p>
            </div>
            
            {/* Badges Earned */}
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-500 bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Trophy className="w-6 h-6 text-yellow-300" />
              </div>
              <p className="text-2xl font-bold">{totalBadges}</p>
              <p className="text-sm opacity-90">Badges</p>
            </div>
            
            {/* XP Points */}
            <div className="text-center">
              <div className="w-12 h-12 bg-green-500 bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Zap className="w-6 h-6 text-green-300" />
              </div>
              <p className="text-2xl font-bold">{xpPoints}</p>
              <p className="text-sm opacity-90">XP Points</p>
            </div>
          </div>
          
          {/* Level Progress */}
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm">Level {levelInfo.current} Progress</span>
              <span className="text-sm">{levelInfo.xpInLevel}/200 XP</span>
            </div>
            <Progress value={(levelInfo.xpInLevel / 200) * 100} className="h-3 bg-white bg-opacity-20" />
            <p className="text-xs opacity-75 mt-1">{levelInfo.xpToNext} XP to Level {levelInfo.current + 1}</p>
          </div>
          
          {/* Overall Course Progress */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm">Course Completion</span>
              <span className="text-sm">{Math.round(overallProgress)}%</span>
            </div>
            <Progress value={overallProgress} className="h-3 bg-white bg-opacity-20" />
          </div>
        </CardContent>
      </Card>
      
      {/* Weekly Goal Card */}
      <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-semibold">This Week's Goal</h4>
            <Star className="w-5 h-5" />
          </div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">{weeklyProgress}/{weeklyGoal} lessons</span>
            <span className="text-sm font-bold">{Math.round(weeklyProgressPercent)}%</span>
          </div>
          <Progress value={weeklyProgressPercent} className="h-2 bg-white bg-opacity-20" />
          {weeklyProgressPercent >= 100 && (
            <p className="text-xs mt-2 font-semibold">🎉 Goal achieved! You're amazing!</p>
          )}
        </CardContent>
      </Card>
      
      {/* Achievement Notifications */}
      {currentStreak > 0 && currentStreak % 7 === 0 && (
        <Card className="bg-gradient-to-r from-orange-500 to-red-500 text-white animate-bounce">
          <CardContent className="p-4 text-center">
            <Flame className="w-8 h-8 mx-auto mb-2" />
            <p className="font-bold">🔥 {currentStreak}-Day Streak! 🔥</p>
            <p className="text-sm">You're on fire! Keep it up!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}