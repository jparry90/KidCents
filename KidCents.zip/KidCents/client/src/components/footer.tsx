export default function Footer() {
  return (
    <footer className="bg-primary-green-dark text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" className="text-primary-green">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  <circle cx="12" cy="6" r="1.5"/>
                  <circle cx="8" cy="12" r="1" opacity="0.7"/>
                  <circle cx="16" cy="12" r="1" opacity="0.7"/>
                </svg>
              </div>
              <h4 className="font-fredoka text-2xl">MoneyBuddies</h4>
            </div>
            <p className="text-green-100 mb-4">Making financial education fun and accessible for every child!</p>
            <div className="flex space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 cursor-pointer transition-colors">
                <i className="fab fa-facebook text-sm"></i>
              </div>
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 cursor-pointer transition-colors">
                <i className="fab fa-twitter text-sm"></i>
              </div>
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 cursor-pointer transition-colors">
                <i className="fab fa-instagram text-sm"></i>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-bold text-lg mb-4">Financial Wisdom</h5>
            <ul className="space-y-2 text-green-100">
              <li><a href="#" className="hover:text-white transition-colors">Stock Market Safari</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Day Trading Detective</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Career Cash Academy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Home Buying Heroes</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-lg mb-4">Parents</h5>
            <ul className="space-y-2 text-green-100">
              <li><a href="#" className="hover:text-white transition-colors">Progress Reports</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Teaching Guide</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Safety & Privacy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Support</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-lg mb-4">Advanced Topics</h5>
            <ul className="space-y-2 text-green-100">
              <li><a href="#" className="hover:text-white transition-colors">401(k) & Retirement</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Investment Detective</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Debt Management</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Entrepreneurship</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-green-600 mt-8 pt-8 text-center">
          <p className="text-green-100">&copy; 2024 MoneyBuddies. Made with love for amazing kids everywhere!</p>
        </div>
      </div>
    </footer>
  );
}