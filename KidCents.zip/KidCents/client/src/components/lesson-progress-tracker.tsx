import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { CheckCircle, Circle, Clock, Star } from "lucide-react";

interface LessonProgressTrackerProps {
  currentSection: number;
  totalSections: number;
  sectionTitles: string[];
  completedSections: boolean[];
  onSectionSelect: (sectionIndex: number) => void;
}

export default function LessonProgressTracker({
  currentSection,
  totalSections,
  sectionTitles,
  completedSections,
  onSectionSelect
}: LessonProgressTrackerProps) {
  const progressPercentage = (currentSection / totalSections) * 100;

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-lg text-gray-800">Lesson Progress</h3>
        <div className="flex items-center space-x-2">
          <Star className="w-5 h-5 text-yellow-500 fill-current" />
          <span className="text-sm font-semibold text-gray-600">
            {Math.round(progressPercentage)}% Complete
          </span>
        </div>
      </div>
      
      <Progress value={progressPercentage} className="mb-4 h-3" />
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {sectionTitles.map((title, index) => {
          const isCompleted = completedSections[index];
          const isCurrent = index === currentSection;
          const isAccessible = index <= currentSection;
          
          return (
            <Button
              key={index}
              variant={isCurrent ? "default" : isCompleted ? "secondary" : "outline"}
              size="sm"
              className={`
                flex items-center justify-start space-x-2 p-3 h-auto text-left
                ${isCurrent ? 'bg-primary-green text-white' : ''}
                ${isCompleted ? 'bg-green-100 text-green-800 border-green-300' : ''}
                ${!isAccessible ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105'}
                transition-all duration-200
              `}
              onClick={() => isAccessible && onSectionSelect(index)}
              disabled={!isAccessible}
            >
              {isCompleted ? (
                <CheckCircle className="w-4 h-4 text-green-600" />
              ) : isCurrent ? (
                <Clock className="w-4 h-4" />
              ) : (
                <Circle className="w-4 h-4" />
              )}
              <span className="text-xs font-medium truncate">{title}</span>
            </Button>
          );
        })}
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">
          Section {currentSection + 1} of {totalSections}: {sectionTitles[currentSection]}
        </p>
      </div>
    </div>
  );
}