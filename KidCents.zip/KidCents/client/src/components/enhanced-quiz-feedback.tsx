import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, X, Lightbulb, ArrowRight } from "lucide-react";

interface EnhancedQuizFeedbackProps {
  question: string;
  options: string[];
  selectedAnswer: number;
  correctAnswer: number;
  explanation?: string;
  onContinue: () => void;
}

export default function EnhancedQuizFeedback({
  question,
  options,
  selectedAnswer,
  correctAnswer,
  explanation,
  onContinue
}: EnhancedQuizFeedbackProps) {
  const isCorrect = selectedAnswer === correctAnswer;

  return (
    <Card className={`rounded-2xl shadow-lg border-2 ${isCorrect ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
      <CardContent className="p-6">
        {/* Header with result */}
        <div className="flex items-center space-x-3 mb-4">
          {isCorrect ? (
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
          ) : (
            <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
              <X className="w-6 h-6 text-white" />
            </div>
          )}
          <div>
            <h3 className={`font-bold text-lg ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
              {isCorrect ? 'Excellent!' : 'Not quite right'}
            </h3>
            <p className={`text-sm ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
              {isCorrect ? 'You got it correct!' : 'Let\'s learn from this'}
            </p>
          </div>
        </div>

        {/* Question reminder */}
        <div className="mb-4">
          <p className="text-gray-700 font-medium mb-3">{question}</p>
        </div>

        {/* Answer options with feedback */}
        <div className="space-y-2 mb-4">
          {options.map((option, index) => (
            <div 
              key={index}
              className={`
                p-3 rounded-xl border-2 flex items-center justify-between
                ${index === correctAnswer ? 'border-green-500 bg-green-100' : 
                  index === selectedAnswer && index !== correctAnswer ? 'border-red-500 bg-red-100' : 
                  'border-gray-200 bg-gray-50'}
              `}
            >
              <span className={`
                ${index === correctAnswer ? 'text-green-800 font-semibold' : 
                  index === selectedAnswer && index !== correctAnswer ? 'text-red-800' : 
                  'text-gray-600'}
              `}>
                {option}
              </span>
              {index === correctAnswer && (
                <CheckCircle className="w-5 h-5 text-green-600" />
              )}
              {index === selectedAnswer && index !== correctAnswer && (
                <X className="w-5 h-5 text-red-600" />
              )}
            </div>
          ))}
        </div>

        {/* Explanation section */}
        {explanation && (
          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-4 rounded-r-xl">
            <div className="flex items-start space-x-2">
              <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-semibold text-blue-800 mb-1">Why this matters:</h4>
                <p className="text-blue-700 text-sm">{explanation}</p>
              </div>
            </div>
          </div>
        )}

        {/* Continue button */}
        <div className="text-center">
          <Button 
            onClick={onContinue}
            className={`
              ${isCorrect ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'} 
              text-white font-semibold py-3 px-6 rounded-2xl flex items-center space-x-2 mx-auto
            `}
          >
            <span>{isCorrect ? 'Continue Learning!' : 'I Understand!'}</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}