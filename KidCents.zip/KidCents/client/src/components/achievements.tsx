import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import type { Achievement } from "@shared/schema";

const achievementColors = {
  yellow: "from-yellow-400 to-yellow-500",
  green: "from-primary-green to-primary-green-dark",
  orange: "from-primary-orange to-primary-orange-dark",
  red: "from-red-500 to-red-600",
  blue: "from-blue-500 to-blue-600",
  pink: "from-pink-500 to-purple-500",
  purple: "from-purple-500 to-purple-600",
  indigo: "from-indigo-500 to-indigo-600",
  cyan: "from-cyan-500 to-cyan-600",
  gold: "from-yellow-400 to-orange-500",
  rainbow: "from-pink-500 via-purple-500 to-blue-500",
  platinum: "from-gray-400 to-gray-600",
};

export default function Achievements() {
  const { data: achievements = [], isLoading } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-primary-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="font-fredoka text-4xl text-white mb-4">Collect Amazing Rewards!</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <Card key={i} className="h-48 animate-pulse">
                <CardContent className="h-full bg-green-200 rounded-2xl"></CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-primary-green">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="font-fredoka text-4xl text-white mb-4">Collect Amazing Rewards!</h3>
          <p className="text-lg text-green-50">Complete lessons and earn cool badges, stickers, and special prizes!</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {achievements.map((achievement, index) => {
            const colorClass = achievementColors[achievement.color as keyof typeof achievementColors] || achievementColors.green;
            const isEarned = index === 0 || index === 1;
            const inProgress = index === 2;
            const progress = isEarned ? "Earned!" : inProgress ? "2/3 completed" : "Locked";
            const opacity = isEarned || inProgress ? "" : "opacity-60";
            
            return (
              <Card 
                key={achievement.id}
                className={`bg-gradient-to-br ${colorClass} rounded-2xl p-6 text-center shadow-lg transform hover:scale-105 transition-transform ${opacity}`}
              >
                <CardContent className="p-0">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center relative ${isEarned || inProgress ? 'bg-white shadow-xl border-2 border-yellow-400' : 'bg-gray-100 border-2 border-gray-300'}`}>
                    {isEarned && (
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center">
                        <i className="fas fa-crown text-white text-xs"></i>
                      </div>
                    )}
                    {inProgress && (
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                        <i className="fas fa-clock text-white text-xs"></i>
                      </div>
                    )}
                    {achievement.icon.includes('chart-line') ? (
                      <svg width="28" height="28" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#3b82f6' : '#9ca3af'}>
                        <path d="M3 17l3-3 4 4 6-6 5 5v-8h-3l-1-2h-2l-2 3-4-4-3 3-3-3v11z"/>
                        <circle cx="6" cy="14" r="1.5" opacity="0.8"/>
                        <circle cx="10" cy="18" r="1.5" opacity="0.8"/>
                        <circle cx="16" cy="12" r="1.5" opacity="0.8"/>
                        {isEarned && <circle cx="20" cy="8" r="2" fill="#ffd700" opacity="0.7"/>}
                      </svg>
                    ) : achievement.icon.includes('bolt') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M11 21h-1l1-7H7l4-7h1l-1 7h4l-4 7z"/>
                        <circle cx="13" cy="9" r="0.5" opacity="0.7"/>
                        <circle cx="9" cy="15" r="0.5" opacity="0.7"/>
                      </svg>
                    ) : achievement.icon.includes('briefcase') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M10 2h4v4h6v14H4V6h6V2zm2 2v2h4V4h-4z"/>
                        <rect x="7" y="9" width="10" height="0.5" opacity="0.7"/>
                        <rect x="7" y="11" width="6" height="0.5" opacity="0.7"/>
                      </svg>
                    ) : achievement.icon.includes('leaf') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12 6.5 2 12 2z"/>
                        <path d="M8 12l2 2 4-4" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" fill="none"/>
                      </svg>
                    ) : achievement.icon.includes('home') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
                        <rect x="11" y="16" width="2" height="2" opacity="0.7"/>
                        <rect x="7" y="14" width="2" height="2" opacity="0.7"/>
                      </svg>
                    ) : achievement.icon.includes('piggy-bank') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <circle cx="12" cy="12" r="8"/>
                        <path d="M12 6v6l4 2"/>
                        <circle cx="8" cy="10" r="0.8"/>
                        <circle cx="16" cy="10" r="0.8"/>
                      </svg>
                    ) : achievement.icon.includes('search-dollar') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <circle cx="11" cy="11" r="6" stroke="currentColor" strokeWidth="1.5" fill="none"/>
                        <path d="M21 21l-3.5-3.5"/>
                        <path d="M11 8v6M8.5 11h5"/>
                      </svg>
                    ) : achievement.icon.includes('credit-card') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <rect x="2" y="5" width="20" height="14" rx="2"/>
                        <rect x="2" y="9" width="20" height="2" opacity="0.7"/>
                        <rect x="4" y="12" width="4" height="1" opacity="0.8"/>
                        <rect x="10" y="12" width="6" height="1" opacity="0.8"/>
                      </svg>
                    ) : achievement.icon.includes('calculator') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <rect x="4" y="2" width="16" height="20" rx="2"/>
                        <rect x="6" y="4" width="12" height="3" opacity="0.7"/>
                        <circle cx="8" cy="10" r="0.8"/>
                        <circle cx="12" cy="10" r="0.8"/>
                        <circle cx="16" cy="10" r="0.8"/>
                        <circle cx="8" cy="14" r="0.8"/>
                        <circle cx="12" cy="14" r="0.8"/>
                        <circle cx="16" cy="14" r="0.8"/>
                      </svg>
                    ) : achievement.icon.includes('crown') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M5 16l3-8 4 4 4-4 3 8H5z"/>
                        <circle cx="5" cy="8" r="1.5"/>
                        <circle cx="12" cy="4" r="1.5"/>
                        <circle cx="19" cy="8" r="1.5"/>
                        <rect x="4" y="16" width="16" height="2"/>
                      </svg>
                    ) : achievement.icon.includes('shield-alt') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M12 2l8 3v7c0 5.55-3.84 10.74-9 12-5.16-1.26-9-6.45-9-12V5l8-3z"/>
                        <path d="M9 12l2 2 4-4" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" fill="none"/>
                      </svg>
                    ) : achievement.icon.includes('hammer') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.77 3.77z"/>
                      </svg>
                    ) : achievement.icon.includes('rocket') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M12 2c0 0 8 4 8 12l-2 2-6-6-6 6-2-2c0-8 8-12 8-12z"/>
                        <circle cx="12" cy="8" r="1.5" opacity="0.7"/>
                        <path d="M8 18c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2"/>
                        <rect x="6" y="15" width="2" height="2" opacity="0.6"/>
                        <rect x="16" y="15" width="2" height="2" opacity="0.6"/>
                      </svg>
                    ) : achievement.icon.includes('graduation-cap') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M12 3L1 9l4 2.18v6L12 21l7-3.82v-6L23 9l-11-6z"/>
                        <circle cx="12" cy="12" r="1" opacity="0.8"/>
                      </svg>
                    ) : achievement.icon.includes('trophy') ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <path d="M7 4V2a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v2h4v6a3 3 0 0 1-3 3h-1.5A5.5 5.5 0 0 1 11 18v2h2v2H5v-2h2v-2a5.5 5.5 0 0 1-4.5-5H1a3 3 0 0 1-3-3V4h4z"/>
                        <circle cx="12" cy="10" r="1" opacity="0.8"/>
                      </svg>
                    ) : (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill={isEarned ? '#eab308' : inProgress ? '#6b7280' : '#9ca3af'}>
                        <circle cx="12" cy="12" r="8"/>
                        <path d="M12 6v6l4 2"/>
                        <circle cx="12" cy="12" r="1.5" opacity="0.7"/>
                      </svg>
                    )}
                  </div>
                  <h4 className={`font-bold text-white text-lg mb-2 ${!isEarned && index !== 0 ? 'opacity-60' : ''}`}>
                    {achievement.name}
                  </h4>
                  <p className="text-white text-opacity-90 text-sm mb-3">{achievement.description}</p>
                  <div className="text-xs text-white text-opacity-80">{progress}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Reward showcase */}
        <div className="mt-12 bg-gradient-to-r from-primary-green to-primary-orange rounded-3xl p-8 text-center">
          <h4 className="font-fredoka text-3xl text-white mb-4">Special Rewards Await! 🎁</h4>
          <p className="text-white text-lg mb-6">Complete all lessons to unlock the ultimate Money Master certificate!</p>
          <div className="flex justify-center space-x-4">
            <div className="bg-white bg-opacity-20 rounded-2xl p-4">
              <i className="fas fa-certificate text-white text-3xl mb-2"></i>
              <p className="text-white text-sm font-bold">Certificate</p>
            </div>
            <div className="bg-white bg-opacity-20 rounded-2xl p-4">
              <i className="fas fa-trophy text-white text-3xl mb-2"></i>
              <p className="text-white text-sm font-bold">Trophy</p>
            </div>
            <div className="bg-white bg-opacity-20 rounded-2xl p-4">
              <i className="fas fa-crown text-white text-3xl mb-2"></i>
              <p className="text-white text-sm font-bold">Crown</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
