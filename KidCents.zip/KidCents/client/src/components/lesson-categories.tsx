import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useLocation } from "wouter";
import type { LessonCategory } from "@shared/schema";

const categoryColors = {
  green: "from-primary-green to-primary-green-dark",
  orange: "from-primary-orange to-primary-orange-dark", 
  red: "from-red-500 to-red-600",
  blue: "from-blue-500 to-blue-600",
  pink: "from-pink-500 to-purple-500",
  yellow: "from-yellow-400 to-yellow-500",
  purple: "from-purple-500 to-purple-600",
  indigo: "from-indigo-500 to-indigo-600",
  cyan: "from-cyan-500 to-cyan-600",
  gold: "from-yellow-400 to-orange-500",
  teal: "from-teal-500 to-teal-600",
  slate: "from-slate-500 to-slate-600",
  emerald: "from-emerald-500 to-emerald-600",
};

export default function LessonCategories() {
  const [, setLocation] = useLocation();
  
  const { data: categories = [], isLoading } = useQuery<LessonCategory[]>({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-primary-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="font-fredoka text-4xl text-white mb-4">Choose Your Adventure!</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1,2,3,4,5,6].map(i => (
              <Card key={i} className="h-64 animate-pulse">
                <CardContent className="h-full bg-green-200 rounded-3xl"></CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-primary-green" data-lesson-categories>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="font-fredoka text-4xl text-white mb-4">Choose Your Adventure!</h3>
          <p className="text-lg text-green-50 max-w-2xl mx-auto">
            Pick a topic and start learning with your money buddies. Each lesson is packed with fun games and activities!
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => {
            const colorClass = categoryColors[category.color as keyof typeof categoryColors] || categoryColors.green;
            const progressValue = index === 0 ? 33 : index === 1 ? 67 : index === 5 ? 75 : 0;
            
            // Map each category to its first lesson ID
            const categoryLessonMap: Record<number, number> = {
              1: 1,   // Stock Market Safari -> lesson 1 (What Are Stocks?)
              2: 6,   // Day Trading Detectives -> lesson 6 (Day Trading: The Speed Game)
              3: 7,   // Career Cash Academy -> lesson 7 (Finding Your Dream Job)
              4: 4,   // Free Fun Financial Club -> lesson 4 (Bonds and Mutual Funds)
              5: 5,   // Home Buying Heroes -> lesson 5 (Credit Cards and Credit Scores)
              6: 14,  // Retirement Rangers -> lesson 14 (401(k) and Retirement Planning)
              7: 15,  // Investment Investigators -> lesson 15 (Advanced Investment Strategies)
              8: 16,  // Credit Card Captains -> lesson 16 (Mastering Credit and Loans)
              9: 9,   // Tax Time Teachers -> lesson 9 (Understanding Taxes)
              10: 10, // Wealth Wisdom Warriors -> lesson 10 (Building Wealth Strategies)
              11: 11, // Insurance Investigators -> lesson 11 (Insurance Protection Plans)
              12: 12, // Debt Destroyers -> lesson 12 (Crushing Debt Forever)
              13: 13  // Entrepreneur Eagles -> lesson 13 (Starting Your Own Business)
            };
            
            const firstLessonId = categoryLessonMap[category.id] || 1;
            
            return (
              <div 
                key={category.id}
                className={`bg-gradient-to-br ${colorClass} rounded-3xl p-8 text-center shadow-xl hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 cursor-pointer group`}
                onClick={() => setLocation(`/lesson/${firstLessonId}`)}
              >
                  <div className="mb-6">
                    <div className="w-24 h-24 mx-auto rounded-2xl bg-white bg-opacity-20 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      {category.icon.includes('chart-line') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M3 17l3-3 4 4 6-6 5 5v-8h-3l-1-2h-2l-2 3-4-4-3 3-3-3v11z"/>
                          <circle cx="6" cy="14" r="1.5"/>
                          <circle cx="10" cy="18" r="1.5"/>
                          <circle cx="16" cy="12" r="1.5"/>
                        </svg>
                      ) : category.icon.includes('bolt') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M11 21h-1l1-7H7l4-7h1l-1 7h4l-4 7z"/>
                          <circle cx="13" cy="9" r="1" opacity="0.7"/>
                          <circle cx="9" cy="15" r="1" opacity="0.7"/>
                        </svg>
                      ) : category.icon.includes('briefcase') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M10 2h4v4h6v14H4V6h6V2zm2 2v2h4V4h-4z"/>
                          <rect x="7" y="9" width="10" height="1" opacity="0.7"/>
                          <rect x="7" y="11" width="6" height="1" opacity="0.7"/>
                        </svg>
                      ) : category.icon.includes('leaf') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M12 2c5.5 0 10 4.5 10 10s-4.5 10-10 10S2 17.5 2 12 6.5 2 12 2z"/>
                          <path d="M8 12l2 2 4-4" stroke="rgba(255,255,255,0.3)" strokeWidth="2" fill="none"/>
                        </svg>
                      ) : category.icon.includes('home') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
                          <rect x="11" y="16" width="2" height="2" opacity="0.7"/>
                          <rect x="7" y="14" width="2" height="2" opacity="0.7"/>
                        </svg>
                      ) : category.icon.includes('piggy-bank') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <circle cx="12" cy="12" r="8"/>
                          <path d="M12 6v6l4 2"/>
                          <circle cx="8" cy="10" r="1"/>
                          <circle cx="16" cy="10" r="1"/>
                        </svg>
                      ) : category.icon.includes('search-dollar') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <circle cx="11" cy="11" r="8" stroke="white" strokeWidth="2" fill="none"/>
                          <path d="M21 21l-4.35-4.35"/>
                          <path d="M11 8v6M8 11h6"/>
                        </svg>
                      ) : category.icon.includes('credit-card') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <rect x="2" y="5" width="20" height="14" rx="2"/>
                          <rect x="2" y="9" width="20" height="2" opacity="0.7"/>
                          <rect x="4" y="12" width="4" height="1" opacity="0.8"/>
                          <rect x="10" y="12" width="6" height="1" opacity="0.8"/>
                        </svg>
                      ) : category.icon.includes('calculator') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <rect x="4" y="2" width="16" height="20" rx="2"/>
                          <rect x="6" y="4" width="12" height="3" opacity="0.7"/>
                          <circle cx="8" cy="10" r="1"/>
                          <circle cx="12" cy="10" r="1"/>
                          <circle cx="16" cy="10" r="1"/>
                          <circle cx="8" cy="14" r="1"/>
                          <circle cx="12" cy="14" r="1"/>
                          <circle cx="16" cy="14" r="1"/>
                        </svg>
                      ) : category.icon.includes('crown') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M5 16l3-8 4 4 4-4 3 8H5z"/>
                          <circle cx="5" cy="8" r="2"/>
                          <circle cx="12" cy="4" r="2"/>
                          <circle cx="19" cy="8" r="2"/>
                          <rect x="4" y="16" width="16" height="2"/>
                        </svg>
                      ) : category.icon.includes('shield-alt') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M12 2l8 3v7c0 5.55-3.84 10.74-9 12-5.16-1.26-9-6.45-9-12V5l8-3z"/>
                          <path d="M9 12l2 2 4-4" stroke="rgba(255,255,255,0.3)" strokeWidth="2" fill="none"/>
                        </svg>
                      ) : category.icon.includes('hammer') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.77 3.77z"/>
                        </svg>
                      ) : category.icon.includes('rocket') ? (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <path d="M12 2c0 0 8 4 8 12l-2 2-6-6-6 6-2-2c0-8 8-12 8-12z"/>
                          <circle cx="12" cy="8" r="2" opacity="0.7"/>
                          <path d="M8 18c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2"/>
                          <rect x="6" y="15" width="3" height="3" opacity="0.6"/>
                          <rect x="15" y="15" width="3" height="3" opacity="0.6"/>
                        </svg>
                      ) : (
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
                          <circle cx="12" cy="12" r="8"/>
                          <path d="M12 4v8l4 2"/>
                          <circle cx="12" cy="12" r="2" opacity="0.7"/>
                        </svg>
                      )}
                    </div>
                  </div>
                  <h4 className="font-fredoka text-2xl text-white mb-3">{category.name}</h4>
                  <p className="text-white text-opacity-90 mb-6 text-sm">{category.description}</p>
                  <div className="flex items-center justify-between text-white text-sm">
                    <span className="flex items-center">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="white" className="mr-1">
                        <path d="M4 6h16v12H4V6zm2 2v8h12V8H6z"/>
                      </svg>
                      {5 + index} Lessons
                    </span>
                    <span className="flex items-center">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="white" className="mr-1">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 6v6l4 2"/>
                      </svg>
                      {10 + index * 2} min each
                    </span>
                  </div>
                  <div className="mt-4">
                    <Progress value={progressValue} className="bg-white bg-opacity-20" />
                  </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
