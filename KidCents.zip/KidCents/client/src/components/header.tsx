import { Link } from "wouter";

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-green-500 to-green-600 text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                <i className="fas fa-graduation-cap text-green-600 text-xl"></i>
              </div>
              <div>
                <h1 className="font-fredoka text-2xl font-bold">MoneyBuddies</h1>
                <p className="text-green-100 text-sm">Financial Learning for Kids</p>
              </div>
            </div>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-white hover:text-green-200 transition-colors">
              Home
            </Link>
            <Link href="/dashboard" className="text-white hover:text-green-200 transition-colors">
              Dashboard
            </Link>
            <a href="#lessons" className="text-white hover:text-green-200 transition-colors">
              Browse Lessons
            </a>
            <a href="#achievements" className="text-white hover:text-green-200 transition-colors">
              Achievements
            </a>
            
            {/* Premium Button */}
            <Link href="/pricing" className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold py-2 px-6 rounded-full transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center space-x-2">
              <i className="fas fa-crown text-sm"></i>
              <span>Get Premium</span>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white">
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>
    </header>
  );
}