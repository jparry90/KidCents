import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Coins, Target, Calendar, TrendingUp } from "lucide-react";

export default function InteractiveSavingsSimulator() {
  const [savingGoal, setSavingGoal] = useState("Nintendo Switch");
  const [goalCost, setGoalCost] = useState(300);
  const [weeklyAmount, setWeeklyAmount] = useState(10);
  const [startingAmount, setStartingAmount] = useState(0);
  
  const weeksNeeded = Math.ceil((goalCost - startingAmount) / weeklyAmount);
  const monthsNeeded = Math.ceil(weeksNeeded / 4);
  const totalSaved = startingAmount + (weeksNeeded * weeklyAmount);
  const extraAmount = totalSaved - goalCost;
  const progressPercentage = (startingAmount / goalCost) * 100;

  const milestones = [
    { week: Math.ceil(weeksNeeded * 0.25), amount: goalCost * 0.25, label: "Quarter Way!" },
    { week: Math.ceil(weeksNeeded * 0.5), amount: goalCost * 0.5, label: "Halfway There!" },
    { week: Math.ceil(weeksNeeded * 0.75), amount: goalCost * 0.75, label: "Almost Done!" },
    { week: weeksNeeded, amount: goalCost, label: "Goal Achieved!" }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-xl text-gray-800">Interactive Savings Planner</h3>
              <p className="text-gray-600">Plan your path to financial success!</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Input Controls */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="goal" className="text-sm font-medium text-gray-700">What do you want to save for?</Label>
                <Input
                  id="goal"
                  value={savingGoal}
                  onChange={(e) => setSavingGoal(e.target.value)}
                  placeholder="e.g., Nintendo Switch, Bike, College"
                  className="mt-1"
                />
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-700">Goal Cost: ${goalCost}</Label>
                <Slider
                  value={[goalCost]}
                  onValueChange={(value) => setGoalCost(value[0])}
                  max={1000}
                  min={10}
                  step={10}
                  className="mt-2"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>$10</span>
                  <span>$1,000</span>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-700">Weekly Savings: ${weeklyAmount}</Label>
                <Slider
                  value={[weeklyAmount]}
                  onValueChange={(value) => setWeeklyAmount(value[0])}
                  max={50}
                  min={1}
                  step={1}
                  className="mt-2"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>$1/week</span>
                  <span>$50/week</span>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-700">Starting Amount: ${startingAmount}</Label>
                <Slider
                  value={[startingAmount]}
                  onValueChange={(value) => setStartingAmount(value[0])}
                  max={goalCost * 0.5}
                  min={0}
                  step={5}
                  className="mt-2"
                />
              </div>
            </div>

            {/* Results Display */}
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-4 shadow-sm">
                <div className="flex items-center space-x-2 mb-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span className="font-semibold text-gray-800">Timeline</span>
                </div>
                <p className="text-lg font-bold text-blue-600">
                  {weeksNeeded} weeks ({monthsNeeded} months)
                </p>
                <p className="text-sm text-gray-600">to reach your goal!</p>
              </div>

              <div className="bg-white rounded-xl p-4 shadow-sm">
                <div className="flex items-center space-x-2 mb-2">
                  <Coins className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-gray-800">Total Saved</span>
                </div>
                <p className="text-lg font-bold text-green-600">${totalSaved}</p>
                {extraAmount > 0 && (
                  <p className="text-sm text-green-600">+${extraAmount} extra!</p>
                )}
              </div>

              <div className="bg-white rounded-xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-gray-800">Progress</span>
                  <span className="text-sm text-gray-600">{progressPercentage.toFixed(1)}%</span>
                </div>
                <Progress value={progressPercentage} className="mb-2" />
                <p className="text-xs text-gray-600">Current savings: ${startingAmount}</p>
              </div>
            </div>
          </div>

          {/* Milestones */}
          <div className="mt-6">
            <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Savings Milestones
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {milestones.map((milestone, index) => (
                <div key={index} className="bg-white rounded-lg p-3 text-center shadow-sm border-l-4 border-blue-500">
                  <p className="font-bold text-blue-600">Week {milestone.week}</p>
                  <p className="text-sm text-gray-600">${milestone.amount}</p>
                  <p className="text-xs text-gray-500">{milestone.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Motivational Message */}
          <div className="mt-6 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl p-4 text-white text-center">
            <p className="font-semibold">
              "Every dollar saved brings you closer to your {savingGoal}! 
              {weeklyAmount >= 20 ? " You're saving like a champion!" : " Small steps lead to big dreams!"}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}