import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function SampleLesson() {
  return (
    <section className="py-16 bg-primary-green">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="font-fredoka text-4xl text-white mb-4">Take a Peek!</h3>
          <p className="text-lg text-green-50">Here's what our lessons look like - fun, simple, and super engaging!</p>
        </div>

        <Card className="bg-green-50 rounded-3xl shadow-2xl p-8 max-w-4xl mx-auto">
          <CardContent className="p-0">
            {/* Lesson header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-primary-green rounded-2xl flex items-center justify-center">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="white">
                    <path d="M5 9.2h3L9 4v5.2h3L17 7v8l-4-3.5H10l-2 5.3H5V9.2z"/>
                  </svg>
                </div>
                <div>
                  <h4 className="font-fredoka text-2xl text-gray-800">Lesson 1: What Are Stocks?</h4>
                  <p className="text-gray-600">Learn how you can own pieces of your favorite companies!</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500 mb-1">Progress</div>
                <Progress value={50} className="w-32" />
              </div>
            </div>

            {/* Lesson content */}
            <div className="grid lg:grid-cols-2 gap-8">
              <div>
                {/* Character explaining concept */}
                <div className="bg-primary-green bg-opacity-10 rounded-2xl p-6 mb-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-primary-green rounded-full flex items-center justify-center flex-shrink-0">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="white">
                        <circle cx="12" cy="8" r="3"/>
                        <path d="M12 14s-4 2-4 4v2h8v-2c0-2-4-4-4-4z"/>
                      </svg>
                    </div>
                    <div>
                      <h5 className="font-bold text-primary-green-dark mb-2">Captain Cash says:</h5>
                      <p className="text-gray-700 leading-relaxed mb-3">
                        "Ahoy there, young investor! Did you know you can actually own a tiny piece of Disney, Apple, or McDonald's?"
                      </p>
                      <p className="text-gray-700 leading-relaxed">
                        "Imagine your friend Sarah opens a pizza shop and needs $1,000 to start. She could sell 100 'shares' for $10 each. 
                        If you buy 1 share, you own 1% of her pizza business! If the pizza shop makes money, your share becomes worth more! 
                        That's how stocks work - you own pieces of real companies!"
                      </p>
                    </div>
                  </div>
                </div>

                {/* Interactive element */}
                <div className="bg-accent-yellow bg-opacity-20 rounded-2xl p-6">
                  <h6 className="font-bold text-gray-800 mb-4">Stock Quiz!</h6>
                  <p className="text-gray-700 mb-4">If you own 5 shares of a company that has 100 total shares, what percentage do you own?</p>
                  <div className="flex space-x-2">
                    <Button className="bg-primary-green text-white hover:bg-primary-green-dark">
                      5%
                    </Button>
                    <Button variant="outline" className="border-2 border-primary-green text-primary-green-dark hover:bg-primary-green hover:text-white">
                      10%
                    </Button>
                    <Button variant="outline" className="border-2 border-primary-green text-primary-green-dark hover:bg-primary-green hover:text-white">
                      50%
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                {/* Visual representation */}
                <div className="text-center">
                  <div className="w-full h-64 bg-gradient-to-br from-primary-green to-blue-400 rounded-2xl shadow-lg mb-6 flex items-center justify-center">
                    <svg width="120" height="120" viewBox="0 0 24 24" fill="white">
                      <path d="M3 17l3-3 4 4 6-6 5 5v-8h-3l-1-2h-2l-2 3-4-4-3 3-3-3v11z"/>
                      <circle cx="6" cy="14" r="1.5" opacity="0.8"/>
                      <circle cx="10" cy="18" r="1.5" opacity="0.8"/>
                      <circle cx="16" cy="12" r="1.5" opacity="0.8"/>
                      <circle cx="20" cy="16" r="1.5" opacity="0.8"/>
                    </svg>
                  </div>
                  
                  {/* Progress visualization */}
                  <div className="bg-green-100 rounded-2xl p-6">
                    <h6 className="font-bold text-gray-800 mb-4">Your Saving Journey</h6>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Week 1</span>
                        <div className="w-6 h-6 bg-primary-green rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">$2</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Week 2</span>
                        <div className="w-6 h-6 bg-primary-green rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">$4</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Week 3</span>
                        <div className="w-6 h-6 bg-primary-green rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">$6</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Lesson navigation */}
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
              <Button variant="outline" className="text-gray-700">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-primary-green rounded-full"></div>
                <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
                <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
                <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
              </div>
              <Button className="bg-primary-orange hover:bg-primary-orange-dark text-white">
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}