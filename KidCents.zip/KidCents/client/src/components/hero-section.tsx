import { Button } from "@/components/ui/button";
import { Play, Book } from "lucide-react";
import { useLocation } from "wouter";

export default function HeroSection() {
  const [, setLocation] = useLocation();
  
  return (
    <section className="bg-gradient-to-br from-primary-green to-primary-green-dark py-16 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="font-fredoka text-5xl lg:text-6xl text-white mb-6 leading-tight">
              Complete Financial Wisdom!
            </h2>
            <p className="text-xl text-green-50 mb-8 leading-relaxed">
              Master EVERYTHING about money: Stock investing with Captain Cash, day trading risks with Flash the Fox, 
              job hunting with Professor Success, money-saving hacks with Thrifty the Turtle, mortgages with Ruby the Realtor, 
              401(k) planning with Wise Owl Winston, advanced wealth strategies with Sage the Eagle, and much more! 
              From basic budgeting to passive income - become a financial genius!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg" 
                className="bg-primary-orange hover:bg-primary-orange-dark text-white font-bold py-4 px-8 rounded-2xl text-lg transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
                onClick={() => setLocation('/lesson/1')}
              >
                <Play className="mr-2 h-5 w-5" />
                Start Learning!
              </Button>
              <Button 
                variant="outline"
                size="lg"
                className="bg-green-100 hover:bg-green-200 text-primary-green-dark font-bold py-4 px-8 rounded-2xl text-lg transform hover:scale-105 transition-all duration-200 shadow-lg border-green-200"
                onClick={() => {
                  const element = document.querySelector('[data-lesson-categories]');
                  element?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                <Book className="mr-2 h-5 w-5" />
                Browse Lessons
              </Button>
            </div>
          </div>
          
          <div className="relative">
            {/* Main character illustration */}
            <div className="relative animate-float">
              <div className="w-80 h-80 mx-auto rounded-3xl shadow-2xl bg-gradient-to-br from-primary-orange via-yellow-400 to-pink-400 flex items-center justify-center relative overflow-hidden">
                {/* Central financial icon */}
                <div className="z-10">
                  <svg width="120" height="120" viewBox="0 0 120 120" className="text-white">
                    {/* Outer financial compass ring */}
                    <circle cx="60" cy="60" r="50" fill="rgba(255,255,255,0.15)" stroke="white" strokeWidth="3"/>
                    <circle cx="60" cy="60" r="42" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="1" strokeDasharray="4,2"/>
                    
                    {/* Central knowledge diamond */}
                    <path d="M60 25 L85 60 L60 95 L35 60 Z" fill="white" opacity="0.9"/>
                    <path d="M60 35 L75 60 L60 85 L45 60 Z" fill="rgba(255,255,255,0.6)"/>
                    
                    {/* Financial symbols around compass */}
                    <text x="60" y="15" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">$</text>
                    <text x="95" y="65" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">%</text>
                    <text x="60" y="110" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">₽</text>
                    <text x="25" y="65" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">€</text>
                    
                    {/* Inner wisdom rays */}
                    <path d="M60 45 L65 50 L60 55 L55 50 Z" fill="rgba(255,255,255,0.8)"/>
                    <path d="M60 65 L65 70 L60 75 L55 70 Z" fill="rgba(255,255,255,0.8)"/>
                    
                    {/* Knowledge dots pattern */}
                    <circle cx="40" cy="40" r="2" fill="white" opacity="0.7"/>
                    <circle cx="80" cy="40" r="2" fill="white" opacity="0.7"/>
                    <circle cx="80" cy="80" r="2" fill="white" opacity="0.7"/>
                    <circle cx="40" cy="80" r="2" fill="white" opacity="0.7"/>
                  </svg>
                </div>
                {/* Background pattern */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute top-4 left-4">
                    <div className="w-6 h-6 bg-white rounded-full"></div>
                  </div>
                  <div className="absolute top-4 right-4">
                    <div className="w-8 h-4 bg-white transform rotate-12"></div>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <div className="w-6 h-6 bg-white border-2 border-transparent"></div>
                  </div>
                  <div className="absolute bottom-4 right-4">
                    <div className="w-6 h-4 bg-white"></div>
                  </div>
                </div>
              </div>
              {/* Character speech bubble */}
              <div className="absolute -top-4 -left-4 bg-white rounded-2xl p-4 shadow-lg animate-bounce-gentle">
                <p className="font-bold text-primary-green-dark text-sm">Learn everything about money!</p>
              </div>
              {/* Additional character bubbles */}
              <div className="absolute -bottom-2 -right-2 bg-white rounded-2xl p-3 shadow-lg animate-bounce-gentle" style={{ animationDelay: '0.5s' }}>
                <p className="font-bold text-primary-orange-dark text-xs">From stocks to savings!</p>
              </div>
            </div>
            
            {/* Floating geometric shapes */}
            <div className="absolute top-10 right-10 animate-wiggle">
              <div className="w-8 h-8 bg-yellow-400 rounded-full border-2 border-yellow-300"></div>
            </div>
            <div className="absolute bottom-10 left-10 animate-bounce">
              <div className="w-6 h-6 bg-primary-orange transform rotate-45"></div>
            </div>
            <div className="absolute top-20 left-5 animate-float">
              <div className="w-8 h-4 bg-blue-300 rounded-sm"></div>
            </div>
            <div className="absolute bottom-20 right-5 animate-pulse-slow">
              <div className="w-0 h-0 border-l-4 border-r-4 border-b-8 border-l-transparent border-r-transparent border-b-green-300"></div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary-green-dark opacity-20 rounded-full transform translate-x-32 -translate-y-32"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-white opacity-10 rounded-full transform -translate-x-24 translate-y-24"></div>
    </section>
  );
}