import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lock, Crown, Star } from "lucide-react";
import { useLocation } from "wouter";

interface PremiumContentGateProps {
  title: string;
  description: string;
  requiredTier: "premium" | "family";
  children?: React.ReactNode;
}

export default function PremiumContentGate({
  title,
  description,
  requiredTier,
  children
}: PremiumContentGateProps) {
  const [, setLocation] = useLocation();

  const handleUpgrade = () => {
    setLocation("/pricing");
  };

  return (
    <Card className="border-2 border-dashed border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50">
      <CardContent className="p-8 text-center">
        {/* Lock Icon */}
        <div className="w-16 h-16 mx-auto mb-4 bg-yellow-500 rounded-full flex items-center justify-center">
          <Lock className="w-8 h-8 text-white" />
        </div>
        
        {/* Premium Badge */}
        <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-4 py-2 rounded-full mb-4">
          <Crown className="w-4 h-4" />
          <span className="font-bold text-sm">
            {requiredTier === "premium" ? "Premium Content" : "Family Plan Content"}
          </span>
        </div>
        
        {/* Content Info */}
        <h3 className="font-fredoka text-2xl text-gray-800 mb-2">{title}</h3>
        <p className="text-gray-600 mb-6 max-w-md mx-auto">{description}</p>
        
        {/* Features Teaser */}
        <div className="bg-white rounded-2xl p-4 mb-6 max-w-sm mx-auto">
          <h4 className="font-semibold text-gray-800 mb-3">Unlock Premium Features:</h4>
          <ul className="text-sm text-gray-600 space-y-2">
            <li className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span>Advanced financial lessons</span>
            </li>
            <li className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span>Interactive calculators</span>
            </li>
            <li className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span>Animated character dialogues</span>
            </li>
            <li className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span>Enhanced progress tracking</span>
            </li>
          </ul>
        </div>
        
        {/* Upgrade Button */}
        <Button 
          onClick={handleUpgrade}
          className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold py-3 px-8 rounded-2xl text-lg shadow-lg transform hover:scale-105 transition-all duration-200"
        >
          <Crown className="w-5 h-5 mr-2" />
          Upgrade to {requiredTier === "premium" ? "Premium" : "Family Plan"}
        </Button>
        
        {/* Pricing Info */}
        <p className="text-sm text-gray-500 mt-4">
          Starting at ${requiredTier === "premium" ? "9.99" : "19.99"}/month • Cancel anytime
        </p>
      </CardContent>
    </Card>
  );
}