import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, Volume2, VolumeX } from "lucide-react";

interface AnimatedCharacterDialogueProps {
  character: string;
  message: string;
  characterIcon: string;
  characterColor: string;
  onContinue?: () => void;
  showContinueButton?: boolean;
}

export default function AnimatedCharacterDialogue({
  character,
  message,
  characterIcon,
  characterColor,
  onContinue,
  showContinueButton = false
}: AnimatedCharacterDialogueProps) {
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);

  useEffect(() => {
    setDisplayedText("");
    setIsTyping(true);
    
    const words = message.split(" ");
    let currentIndex = 0;
    
    const typeInterval = setInterval(() => {
      if (currentIndex < words.length) {
        setDisplayedText(prev => prev + (prev ? " " : "") + words[currentIndex]);
        currentIndex++;
      } else {
        setIsTyping(false);
        clearInterval(typeInterval);
      }
    }, 200); // Adjust typing speed here

    return () => clearInterval(typeInterval);
  }, [message]);

  const characterIcons = {
    "fas fa-coins": "💰",
    "fas fa-bolt": "⚡",
    "fas fa-graduation-cap": "🎓",
    "fas fa-leaf": "🌱",
    "fas fa-home": "🏠",
    "fas fa-owl": "🦉",
    "fas fa-search-dollar": "🔍",
    "fas fa-credit-card": "💳",
    "fas fa-mountain": "🏔️",
    "fas fa-shield-alt": "🛡️",
    "fas fa-hammer": "🔨",
    "fas fa-crown": "👑",
    "fas fa-calculator": "📱"
  };

  return (
    <div className="relative">
      <Card className={`bg-gradient-to-br from-white to-gray-50 border-2 border-${characterColor}-200 shadow-lg transform hover:scale-102 transition-all duration-300`}>
        <CardContent className="p-6">
          <div className="flex items-start space-x-4">
            {/* Character Avatar */}
            <div className={`w-16 h-16 bg-${characterColor}-500 rounded-full flex items-center justify-center flex-shrink-0 relative`}>
              <i className={`${characterIcon} text-white text-2xl`}></i>
              {isTyping && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse">
                  <div className="absolute inset-0 bg-green-400 rounded-full animate-ping"></div>
                </div>
              )}
            </div>
            
            <div className="flex-1">
              {/* Character Name */}
              <div className="flex items-center justify-between mb-3">
                <h4 className={`font-bold text-${characterColor}-800 flex items-center space-x-2`}>
                  <MessageCircle className="w-4 h-4" />
                  <span>{character} says:</span>
                </h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className="p-1 h-8 w-8"
                >
                  {soundEnabled ? (
                    <Volume2 className="w-4 h-4 text-gray-600" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-gray-600" />
                  )}
                </Button>
              </div>
              
              {/* Animated Message */}
              <div className="bg-gray-50 rounded-2xl p-4 relative">
                <p className="text-gray-800 leading-relaxed">
                  {displayedText}
                  {isTyping && (
                    <span className="inline-block w-1 h-5 bg-gray-600 ml-1 animate-blink"></span>
                  )}
                </p>
                
                {/* Speech bubble tail */}
                <div className={`absolute -left-2 top-4 w-0 h-0 border-t-8 border-b-8 border-r-8 border-t-transparent border-b-transparent border-r-gray-50`}></div>
              </div>
              
              {/* Action Buttons */}
              {!isTyping && showContinueButton && onContinue && (
                <div className="mt-4 flex justify-end">
                  <Button 
                    onClick={onContinue}
                    className={`bg-${characterColor}-600 hover:bg-${characterColor}-700 text-white px-4 py-2 rounded-xl`}
                  >
                    Continue
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Floating Character Emotes */}
      <div className="absolute -top-8 left-12 animate-float">
        <div className="bg-white rounded-full p-2 shadow-lg border-2 border-yellow-200">
          <span className="text-sm">💡</span>
        </div>
      </div>
    </div>
  );
}